# Changelog

Todos los cambios notables al proyecto se documentan acá.
Sigue el formato [Keep a Changelog](https://keepachangelog.com/es-ES/1.1.0/) y
versionado semántico [SemVer](https://semver.org/lang/es/).

## [2.1.0] - 2026-06-02

### Agregado
- **Backend MongoDB** alternativo (`server-mongo/`) con Mongoose 8.x
  - 7 modelos: User, Document, Validation, ScoringHistory, ActivityLog, Nft, LegalConsent
  - Transacciones con fallback automático para standalone deployments
  - Conversión de errores Mongo a HTTP status codes amigables
- **Marketplace embebido** en la landing principal — filtros por sector y membresía sobre datos reales del backend
- **Docker Compose** para levantar MySQL + Mongo + Adminer + Mongo Express con un solo comando
- **GitHub Actions CI** que valida frontend, ambos backends y el smart contract en cada PR
- **Dependabot** configurado para PRs semanales de seguridad
- **Plantillas de Issues** (bug/feature) y PR con checklist
- Script `init-github.sh` para inicializar el repo y conectarlo a GitHub
- `docs/API.md` con todos los endpoints documentados

### Cambiado
- Tema visual completo: ahora paleta clara **cyan + violet + gold** sobre fondo blanco con gradients radiales (antes: cyan oscuro)
- Tipografía a Plus Jakarta Sans en todo el sistema
- `/marketplace` ahora redirige a `/#marketplace` (la página existe pero el marketplace vive en el landing)
- Layout del landing: 12 secciones nuevas (decision-box, simple-strip, dos puertas, flow 7 pasos, arquitectura 7 capas, pagos España, propiedad intelectual)

### Mejorado
- `db.js` (MySQL) con `testConnection()`, `getDbStatus()`, `withTransaction()`, `friendlySqlError()` y diagnóstico claro al fallar
- `index.js` ahora verifica DB antes de abrir el puerto — sale rápido si no hay conexión
- Handler global de errores prioriza SQL/Mongo → multer → JSON → fallback
- Seed inicial: 5 usuarios + 15 consentimientos legales + 3 documentos (2 validados + 1 en cola)

## [2.0.0] - 2026-05-29

### Agregado
- **Reescritura completa** de PHP 8.4 a React 18 + Node 22
- Cliente React con Vite 5, React Router 6, AuthContext
- Backend Express con MySQL2 y ethers.js v6
- Smart contract `MTPValidationNFT.sol` (Solidity 0.8.20, ERC-721 self-contained)
- 22 páginas del cliente (público + usuario + verificador + admin)
- Tabla `legal_consents` para auditoría SEPRELAD
- Páginas `/terms`, `/privacy`, `/u/kyc` con flujo de 4 pasos
- Verificador público `/verify` por hash SHA-256, token ID o doc ID
- 6 fases del roadmap del proyecto en la landing
- Marco legal con 6 cards SEPRELAD/Paraguay/España

### Cambiado
- Esquema de DB de 5 tablas a 7 tablas (agregadas `nfts` y `legal_consents`)
- Roles del usuario: ahora 3 (admin · usuario · verificador) — antes 4

## [1.0.0] - 2026-04-15

### Agregado
- Primera versión funcional en PHP 8.4 + MySQL para WAMP Windows
- Login, registro, carga de documentos
- Motor de scoring 0-100 con historial
- 4 tipos de certificación: CTE, CTPI, CEN, CTK

[2.1.0]: https://github.com/TU_USUARIO/mtp-platform/releases/tag/v2.1.0
[2.0.0]: https://github.com/TU_USUARIO/mtp-platform/releases/tag/v2.0.0
[1.0.0]: https://github.com/TU_USUARIO/mtp-platform/releases/tag/v1.0.0
