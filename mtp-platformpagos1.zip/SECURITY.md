# Política de Seguridad

## Versiones soportadas

| Versión | Soportada |
|---------|-----------|
| 2.1.x (Mongo) | ✅ |
| 2.0.x (MySQL) | ✅ |
| < 2.0 | ❌ |

## Reportar una vulnerabilidad

**No abras un Issue público** para reportar vulnerabilidades de seguridad.

Enviá un correo a **security@mtp.platform** (o el email que figure en el repo)
con los siguientes datos:

- Descripción técnica del problema
- Pasos para reproducirlo
- Impacto potencial (qué información o acciones se ven afectadas)
- Tu nombre y forma de contacto (opcional, para reconocimiento)

## Tiempo de respuesta

| Severidad | Primera respuesta | Parche |
|-----------|-------------------|--------|
| Crítica (RCE, fuga de claves) | < 24h | < 72h |
| Alta (auth bypass, SQL injection) | < 48h | < 1 semana |
| Media (XSS, CSRF) | < 1 semana | < 2 semanas |
| Baja | < 2 semanas | siguiente release |

## Áreas con especial cuidado

- **JWT**: no exponer `JWT_SECRET` en logs ni mensajes de error
- **Smart contract**: el `ETTIOS_PRIVATE_KEY` da control del minteo — nunca commitearla
- **KYC**: los datos personales tienen retención de 5 años (SEPRELAD)
- **SHA-256 de archivos**: aunque sea hash, identifica unívocamente un documento
- **Cookies y CORS**: respetá la lista de origins en `CORS_ORIGIN`

## Reconocimiento

Te incluiremos en el archivo `SECURITY-CREDITS.md` si querés (o anónimo si preferís).

¡Gracias por ayudar a mantener seguro al proyecto!
