# API Reference

Todos los endpoints son JSON. Los autenticados requieren el header
`Authorization: Bearer <token>` obtenido en `/api/auth/login`.

Base URL en desarrollo: `http://localhost:4000`

---

## 🌐 Públicos (sin auth)

### `GET /api/health`
Estado de DB + blockchain.

**Response 200:**
```json
{
  "ok": true,
  "app": "MTP Platform",
  "version": "2.1.0-mongo",
  "db": {
    "ok": true,
    "counts": { "users": 5, "documents": 3, "validations": 2, "nfts": 0, "consents": 15 }
  },
  "blockchain": { "name": "ETTIOS", "chainId": 2237, "ok": true }
}
```

### `POST /api/auth/register`
Crear cuenta con 3 consentimientos obligatorios.

**Body:**
```json
{
  "full_name": "Estudio Vega & Asoc.",
  "email": "test@example.com",
  "password": "min6chars",
  "entity_type": "empresa",
  "sector": "Inmobiliario",
  "membership": "profesional",
  "wallet_address": "0x...",
  "accept_terms": true,
  "accept_privacy": true,
  "accept_kyc": true
}
```

### `POST /api/auth/login`
**Body:** `{ "email": "...", "password": "..." }`
**Response:** `{ "user": {...}, "token": "eyJ..." }`

### `GET /api/marketplace/sectors`
Lista de sectores únicos para el filtro.

### `GET /api/marketplace/professionals?sector=&membership=&q=`
Listado público de profesionales verificados.

### `GET /api/marketplace/stats`
Métricas en vivo para el hero del landing.

### `GET /api/verify/:identifier`
Verificación pública. Acepta:
- Hash SHA-256 (64 chars hex)
- Token ID NFT (número grande)
- ObjectId del documento (Mongo) o ID numérico (MySQL)

**Response:**
```json
{
  "ok": true, "found": true,
  "verification_status": "on_chain",
  "certificate": { "id": "...", "title": "...", "file_hash": "..." },
  "owner": { "name": "...", "reputation": 88, "kyc_status": "verificado" },
  "validations": [...],
  "score_breakdown": { "economico": 92, "tributario": 87, "financiero": 92, "laboral": 87 },
  "nft": { "token_id": "142", "tx_hash": "0x...", "explorer_url": "..." }
}
```

### `GET /api/nft`
Registro on-chain público (últimos 100 NFTs minteados).

### `GET /api/nft/metadata/:tokenId`
Metadata pública para `tokenURI()` del smart contract.

---

## 🔒 Autenticados

### `GET /api/auth/me`
Devuelve el user del token actual.

### `POST /api/documents`
**Multipart** con campo `file`.
**Body:** `title`, `doc_type` (cte/ctpi/cen/ctk/contrato/balance/otro), `description`.

### `GET /api/documents`
Lista los documentos del usuario (admin ve todos).

### `GET /api/documents/:id`
Ficha con validaciones + NFT (si existe).

### `POST /api/kyc`
**Body:** `{ "country": "Paraguay", "doc_type": "CI", "doc_number": "...", "wallet_address": "0x..." }`

### `GET /api/kyc/me`
Estado actual del KYC del usuario autenticado.

### `GET /api/kyc/consents`
Log de los consentimientos legales firmados.

### `GET /api/activity/my-scoring`
Historial de cambios de reputación.

### `POST /api/nft/mint/:docId`
Solo el propietario o un admin. Requiere documento `validado` + wallet configurada.

### `GET /api/nft/mine`
NFTs del usuario.

---

## 👨‍⚖️ Verificadores

### `GET /api/validations/queue`
Cola de documentos pendientes de validar.

### `POST /api/validations/take/:docId`
Auto-asignación.

### `POST /api/validations`
Emitir dictamen.
**Body:** `{ "document_id": "...", "val_type": "juridica", "result": "aprobado", "opinion": "..." }`
`result`: `aprobado` (+8 al score), `observado` (-3), `rechazado` (-10).

### `GET /api/validations/mine`
Historial de dictámenes emitidos.

---

## 👑 Admin

### `GET /api/users`
Listado completo.

### `PATCH /api/users/:id/kyc` — `{ "kyc_status": "verificado" }`
### `PATCH /api/users/:id/role` — `{ "role": "verificador" }`
### `PATCH /api/users/:id/membership` — `{ "membership": "premium" }`
### `PATCH /api/users/:id/status` — `{ "status": "suspendido" }`

### `GET /api/users/stats/overview`
Métricas globales del sistema.

### `GET /api/users/scoring/ranking`
Top 20 usuarios por reputación.

### `GET /api/users/scoring/recent`
Últimos 40 cambios de scoring.

### `GET /api/activity/activity?entity=&limit=`
Log global de actividad (auditoría).

### `PATCH /api/documents/:id/assign`
Asignar verificador. **Body:** `{ "verifier_id": "..." }`

---

## ⚠️ Códigos de error comunes

| HTTP | Significado |
|------|-------------|
| `400` | Datos inválidos / falta campo obligatorio |
| `401` | Token ausente o expirado |
| `403` | Sin permisos para esta acción |
| `404` | Recurso no encontrado |
| `409` | Conflicto (email ya registrado, NFT ya minteado, etc.) |
| `503` | Servicio de DB no disponible |

Todos los errores devuelven `{ "error": "mensaje legible en español" }`.
