# Guía de Deployment

Cómo levantar MTP Platform en distintos entornos: local, Docker, VPS y cloud.

## 🏠 Local (desarrollo)

### Opción A — Con Docker Compose (recomendado)

Más simple: arranca DBs sin instalarlas.

```bash
# 1) Levantar DBs en contenedores
docker-compose up -d

# 2) Backend (elegí uno)
cd server      # ← MySQL
# o
cd server-mongo  # ← MongoDB

npm install
cp .env.example .env
npm run init-db
npm run dev

# 3) Frontend (otra terminal)
cd client
npm install
npm run dev
```

Listo: http://localhost:5173

**UIs auxiliares incluidas:**
- Adminer (MySQL): http://localhost:8080 — server `mysql`, user `root`, sin password
- Mongo Express: http://localhost:8081 — user `admin`, pass `mtp1234`

### Opción B — DBs locales nativas

**Windows / WAMP:** prendé MySQL desde el panel WAMP.
**macOS:** `brew services start mysql` o `brew services start mongodb-community`.
**Linux:** `sudo systemctl start mysql` o `mongod`.

Después, los mismos `npm install` + `npm run init-db` + `npm run dev`.

---

## 🐳 Producción con Docker

Acá el ejemplo de Dockerfile para el backend MySQL (similar para Mongo):

```dockerfile
# server/Dockerfile
FROM node:22-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .
RUN mkdir -p uploads
EXPOSE 4000
CMD ["node", "src/index.js"]
```

Frontend:
```dockerfile
# client/Dockerfile
FROM node:22-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
```

`client/nginx.conf` para SPA con proxy al backend:
```nginx
server {
  listen 80;
  root /usr/share/nginx/html;
  index index.html;

  location /api/ {
    proxy_pass http://backend:4000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
  }

  location / {
    try_files $uri /index.html;
  }
}
```

---

## ☁️ Cloud

### Frontend → Vercel / Netlify / Cloudflare Pages

El frontend es un SPA estático. Cualquiera de los 3 lo deploya gratis:

**Vercel:**
```bash
cd client
npx vercel
```
Build command: `npm run build` · Output directory: `dist`

Importante: configurar la **variable de entorno** `VITE_API_URL` apuntando al backend en producción.

### Backend → Render / Fly.io / Railway

Cualquier plataforma que corra Node.js sirve. Render es probablemente la más simple:

1. Conectá el repo en https://render.com
2. New Web Service → Node
3. Root directory: `server` (o `server-mongo`)
4. Build: `npm install`
5. Start: `npm start`
6. Environment variables: copiá tu `.env`

### DB → Cloud managed

- **MySQL**: PlanetScale (free tier), Railway, AWS RDS
- **MongoDB**: MongoDB Atlas (free tier de 512MB es suficiente para arrancar)

Para Atlas:
1. Creá cluster en https://cloud.mongodb.com
2. Network Access → agregá la IP del backend
3. Database Access → creá user con read/write
4. Copiá la connection string: `mongodb+srv://USER:PASS@cluster.xxx.mongodb.net/mtp_platform`
5. Pegalo en `MONGO_URI` del backend

---

## 🔐 Variables de entorno en producción

**Backend (server o server-mongo):**

```env
# Server
PORT=4000
JWT_SECRET=cambiar_por_un_random_largo
JWT_EXPIRES_IN=7d
CORS_ORIGIN=https://tu-dominio.com,https://www.tu-dominio.com

# Database (MySQL)
DB_HOST=tu-host-de-mysql.com
DB_PORT=3306
DB_USER=mtp_user
DB_PASSWORD=password_seguro_aqui
DB_NAME=mtp_platform

# Database (Mongo)
MONGO_URI=mongodb+srv://user:pass@cluster.xxx.mongodb.net/mtp_platform

# Uploads (en cloud usá S3 / Cloudflare R2)
UPLOAD_DIR=./uploads
MAX_UPLOAD_BYTES=8388608

# ETTIOS Blockchain
ETTIOS_RPC_URL=https://rpc.ettiosblockchain.io
ETTIOS_CHAIN_ID=2237
ETTIOS_CONTRACT_ADDRESS=0x...     # Después del deploy del contrato
ETTIOS_PRIVATE_KEY=0x...          # Wallet con saldo de gas
```

**Frontend (client):**

```env
# Solo si hospedás el frontend en un dominio distinto al backend
VITE_API_URL=https://api.tu-dominio.com
```

Por default, Vite hace proxy `/api/*` → `localhost:4000`. En producción
podés mantener ese patrón con nginx o configurar `VITE_API_URL`.

---

## ⛓ Deployar el smart contract en ETTIOS

### Con Remix (el más fácil)

1. Abrí https://remix.ethereum.org
2. File → New file → `MTPValidationNFT.sol`
3. Pegá el contenido de `server/contracts/MTPValidationNFT.sol`
4. Solidity Compiler → seleccioná `0.8.20` → Compile
5. Deploy & Run → Environment: `Injected Provider - MetaMask`
6. En MetaMask, agregá la red ETTIOS:
   - Name: ETTIOS
   - RPC URL: (la que te da Adrián Sirio)
   - Chain ID: 2237
7. Click "Deploy" → confirmar en MetaMask
8. Copiá la **Contract Address** que aparece después del deploy
9. Pegala en `ETTIOS_CONTRACT_ADDRESS` del `.env` del backend

### Si la wallet del backend es distinta a la del deployer:

Después del deploy, llamá `setMinter(addressDelBackend, true)` para autorizar
al backend a mintear NFTs:

```javascript
// En la consola de Remix con el contrato desplegado
await contract.setMinter("0xBackendWalletAddress", true);
```

---

## 🩺 Checks post-deploy

Después de levantar el sistema en producción, verificá:

```bash
# 1) Health check del backend
curl https://api.tu-dominio.com/api/health

# Esperás:
# {
#   "ok": true,
#   "db": { "ok": true, "counts": {...} },
#   "blockchain": { "name": "ETTIOS", "ok": true }
# }

# 2) Frontend responde
curl https://tu-dominio.com  # debería devolver HTML

# 3) Marketplace público funciona
curl https://api.tu-dominio.com/api/marketplace/stats

# 4) Cuenta admin funciona
curl -X POST https://api.tu-dominio.com/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@mtp.test","password":"mtp1234"}'
```

⚠️ **Después de verificar**, cambiá la password de `admin@mtp.test` o eliminá las cuentas demo.

---

## 📊 Monitoring sugerido

- **Backend**: Sentry, Better Stack, o el plan free de Datadog
- **Uptime**: UptimeRobot (gratis, ping cada 5 min)
- **Logs**: el `console.log` que viene en el sistema se puede redirigir a Papertrail o LogTail
- **DB**: backups automáticos (Atlas y RDS los hacen solos; en VPS usar `cron + mysqldump` o `mongodump`)
