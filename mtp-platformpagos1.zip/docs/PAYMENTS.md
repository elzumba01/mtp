# Configurar pagos en MTP Platform

Guía paso a paso para activar **Redsys (CaixaBank/Cyberpac) + Bizum** en el sistema.

## TL;DR — Probar en modo test (sin contratar nada)

Redsys provee credenciales públicas para sandbox. Pegá esto en tu `.env`:

```env
REDSYS_MERCHANT_CODE=999008881
REDSYS_TERMINAL=1
REDSYS_CURRENCY=978
REDSYS_SECRET_KEY=sq7HjrUOBfKmC576ILgskD5srU870gJ7
REDSYS_ENVIRONMENT=test
REDSYS_OK_URL=http://localhost:5173/payments/success
REDSYS_KO_URL=http://localhost:5173/payments/failure
REDSYS_NOTIFICATION_URL=http://localhost:4000/api/payments/notify
BIZUM_ENABLED=false
```

Reiniciás el backend, vas a `http://localhost:5173/checkout`, elegís un plan, pagás con la **tarjeta test 4548 8120 4940 0004** (CVV 123, vence 12/30, código SMS 123456) y debería volver a la página de éxito.

---

## Paso 1 — Contratar Cyberpac con CaixaBank (producción)

### Si todavía no tenés cuenta en CaixaBank Empresas

1. Llamá a la línea CaixaBank Empresas: **900 323 232**
2. Pedí abrir una **cuenta de empresa** para Aston Mining S.L. (NIF/CIF español)
3. Te van a pedir: escrituras de la sociedad, NIF de los administradores, alta en Seguridad Social

### Si ya tenés cuenta empresa en CaixaBank

1. Entrá a https://empresa.lacaixa.es o pedile a tu gestor de cuenta
2. Solicitá el producto **"TPV Virtual Cyberpac"**
3. Vas a tener que firmar:
   - **Contrato de adhesión** al servicio
   - **Anexo de comisiones** (típicamente 0.30 € + 0.5% por transacción)
4. CaixaBank te asigna en 3-5 días hábiles:
   - **Número de comercio (FUC)** — 9 dígitos, ej. `123456789`
   - **Terminal** — generalmente `001` o `1`
   - **Clave del comercio** — string base64 de 32 caracteres
   - **Acceso al Portal de Administración Redsys** (https://canales.redsys.es)

### Agregar Bizum (opcional)

1. Una vez activo Cyberpac, pedí el **addon Bizum**
2. Comisión adicional: ~0.20 € por operación
3. Te activan el método de pago `z` (el código interno de Bizum en Redsys)
4. Cambiá `BIZUM_ENABLED=true` en tu `.env`

---

## Paso 2 — Configurar en el Portal Redsys

Entrás a https://canales.redsys.es con las credenciales que te dio CaixaBank.

### URLs de notificación (críticas)

En el portal:
1. **Administración** → **Datos de Comercio** → **Configuración**
2. Configurá:
   - **URL OK**: donde redirige tras pago exitoso → `https://tu-dominio.com/payments/success`
   - **URL KO**: donde redirige tras pago fallido → `https://tu-dominio.com/payments/failure`
   - **URL de notificación (online)**: webhook que nos notifica → `https://api.tu-dominio.com/api/payments/notify`
3. **Importante**: marcá la opción "Realizar la notificación on-line incluso si la respuesta es KO"

### Si estás en localhost

El webhook **necesita ser accesible desde internet**. Hay 2 opciones:

**Opción A — ngrok (más rápido para probar):**
```bash
ngrok http 4000
# Te da una URL pública: https://abc123.ngrok-free.app
# Configurá REDSYS_NOTIFICATION_URL=https://abc123.ngrok-free.app/api/payments/notify
```

**Opción B — Cloudflare Tunnel (gratis, más estable):**
```bash
cloudflared tunnel --url http://localhost:4000
```

---

## Paso 3 — Llenar el .env de producción

Reemplazá los valores test por los reales:

```env
# Server
PORT=4000
JWT_SECRET=<generá uno largo con: openssl rand -hex 32>
CORS_ORIGIN=https://tu-dominio.com

# DB (lo que ya tengas)
DB_HOST=...
DB_USER=...
DB_PASSWORD=...
DB_NAME=mtp_platform

# Redsys — DATOS REALES de CaixaBank
REDSYS_MERCHANT_CODE=123456789           # FUC que te dio CaixaBank
REDSYS_TERMINAL=1                         # generalmente 1 o 001
REDSYS_CURRENCY=978                       # 978 = EUR (no cambiar)
REDSYS_SECRET_KEY=Mk9m98IfEblmPfrpsawt7BmxObt98Jev   # ← tu clave del comercio
REDSYS_ENVIRONMENT=production             # ¡importante!
REDSYS_OK_URL=https://tu-dominio.com/payments/success
REDSYS_KO_URL=https://tu-dominio.com/payments/failure
REDSYS_NOTIFICATION_URL=https://api.tu-dominio.com/api/payments/notify

# Bizum (si lo contrataste)
BIZUM_ENABLED=true
```

---

## Paso 4 — Probar el flujo completo

### En desarrollo

```bash
# Tarjetas de prueba que provee Redsys:
Tarjeta válida:         4548 8120 4940 0004
CVV:                    123
Caducidad:              12/30
SMS de confirmación:    123456

Tarjeta rechazada:      4548 8127 5042 0001  (cualquier CVV/fecha)
```

Flujo esperado:
1. Vas a `http://localhost:5173/checkout`
2. Elegís plan "Profesional" (29 €) y método "Tarjeta"
3. Click en "Pagar con tarjeta →"
4. El navegador hace POST al TPV Redsys con los 3 campos firmados
5. Llegás a la pantalla de Redsys con el form de tarjeta
6. Ingresás los datos de la tarjeta test
7. Te pide el SMS `123456`
8. Redsys hace 2 cosas en paralelo:
   - Te redirige a `/payments/success`
   - Le pega un POST a `/api/payments/notify`
9. El backend valida la firma del webhook, actualiza el estado a `aprobado`, y si era una membresía, actualiza `users.membership`
10. En el panel del usuario ya aparece como "Profesional"

### Verificar que el webhook llegó

```bash
# Mirá los logs del backend mientras pagás:
docker-compose logs -f server

# O directo en la DB:
mysql -uroot mtp_platform -e "SELECT order_id, status, response_code FROM payments ORDER BY id DESC LIMIT 5"
```

Esperás ver:
```
order_id      status     response_code
1234ABCD5678  aprobado   0
```

---

## Paso 5 — Diagnóstico cuando algo falla

### `GET /api/payments/health`

Llamá este endpoint para ver el estado:

```bash
curl http://localhost:4000/api/payments/health
```

Respuesta:
```json
{
  "redsys": {
    "configured": true,
    "environment": "production",
    "endpoint": "https://sis.redsys.es/sis/realizarPago",
    "merchant_code": "***6789"
  },
  "bizum": {
    "configured": true,
    "enabled": true,
    "environment": "production"
  },
  "prices": {
    "profesional": { "amount": 2900, "label": "Membresía Profesional (mensual)" },
    "premium":     { "amount": 7900, "label": "Membresía Premium (mensual)" },
    "nft":         { "amount": 500,  "label": "Minteo de NFT en ETTIOS" }
  }
}
```

Si `configured: false` → te faltan variables en el `.env`.

### Errores comunes

| Error | Causa | Solución |
|-------|-------|----------|
| `SIS0042` en Redsys | Firma inválida | Revisá que `REDSYS_SECRET_KEY` esté EXACTA (sin espacios) |
| `SIS0051` | Número de pedido repetido | El sistema genera ordenes únicas, no debería pasar — revisar `generateOrderId()` |
| Webhook no llega | URL no accesible | Tu `REDSYS_NOTIFICATION_URL` no es pública. Usá ngrok o Cloudflare Tunnel |
| Bizum: "no disponible" | `BIZUM_ENABLED=false` o no contratado | Pedí el addon a CaixaBank |
| El pago aprueba pero la membresía no se actualiza | El webhook llega pero falla la firma | Mirá logs: `docker-compose logs server | grep payment` |

---

## Paso 6 — Pasar a producción

### Checklist antes del go-live

- [ ] Variables `.env` apuntando a credenciales **reales** de CaixaBank
- [ ] `REDSYS_ENVIRONMENT=production` (no `test`)
- [ ] URLs HTTPS válidas con certificado (Let's Encrypt)
- [ ] `REDSYS_NOTIFICATION_URL` accesible públicamente
- [ ] En el portal Redsys, las URLs OK/KO/Notification coinciden con tu dominio real
- [ ] Generaste `JWT_SECRET` nuevo con `openssl rand -hex 32`
- [ ] Borraste o cambiaste las contraseñas de los usuarios demo (`admin@mtp.test` etc.)
- [ ] Backup automatizado de la DB (incluye tabla `payments`)
- [ ] Logging activado en algún sistema externo (Sentry, LogTail, Papertrail)

### Comisiones esperadas

| Método | Comisión típica CaixaBank |
|--------|---------------------------|
| Tarjeta (Visa/Mastercard) | 0.30 € + 0.5% |
| Bizum | 0.20 € + 0% |
| Devolución | 0.30 € por reembolso |

Para un plan Profesional de 29 €:
- Recibís: 29 € - 0.30 € - 0.145 € (0.5%) = **28.55 €** neto

---

## Endpoints disponibles en el sistema

| Método | Endpoint | Auth | Descripción |
|--------|----------|------|-------------|
| `GET` | `/api/payments/health` | público | Estado de configuración + precios |
| `POST` | `/api/payments/redsys/create` | usuario | Inicia pago con tarjeta |
| `POST` | `/api/payments/bizum/create` | usuario | Inicia pago Bizum |
| `POST` | `/api/payments/notify` | público (firma) | Webhook de Redsys |
| `GET` | `/api/payments/mine` | usuario | Lista mis pagos |
| `GET` | `/api/payments/:orderId` | usuario | Estado de una orden |

---

## Soporte

- **CaixaBank Empresas**: 900 323 232 (gratuito desde España)
- **Redsys Soporte Técnico**: 902 36 28 56 / `soporte@redsys.es`
- **Documentación oficial Redsys**: https://pagosonline.redsys.es/desarrolladores.html
- **Bizum**: https://bizum.es/preguntas-frecuentes/
