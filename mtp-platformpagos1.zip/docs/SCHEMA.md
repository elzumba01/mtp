# Schema de la base de datos

Las 7 tablas/colecciones del sistema MTP Platform. La misma estructura
funciona en MySQL (`server/sql/schema.sql`) y MongoDB
(`server-mongo/src/models/index.js`).

## Diagrama

```
┌─────────────────┐    ┌───────────────────┐    ┌──────────────────┐
│      users      │◄───│     documents     │◄───│   validations    │
├─────────────────┤    ├───────────────────┤    ├──────────────────┤
│ id              │ FK │ id                │    │ id               │
│ email (unique)  │    │ user_id           │ FK │ document_id      │
│ password_hash   │    │ title             │    │ verifier_id      │
│ role            │    │ doc_type          │    │ val_type         │
│ reputation      │    │ file_hash         │    │ result           │
│ membership      │    │ status            │    │ score_impact     │
│ kyc_status      │    │ ai_risk           │    │ opinion          │
│ wallet_address  │    │ ai_summary        │    └──────────────────┘
│ ... (26 cols)   │    │ assigned_to       │ FK
└─────────────────┘    │ ... (13 cols)     │
       │  ▲            └───────────────────┘
       │  │                     ▲
       │  │  ┌──────────────────┘
       ▼  │  │
┌─────────────────┐    ┌───────────────────┐
│ scoring_history │    │       nfts        │
├─────────────────┤    ├───────────────────┤
│ user_id         │ FK │ document_id       │ FK
│ document_id     │ FK │ user_id           │ FK
│ validation_id   │ FK │ token_id          │
│ prev_score      │    │ tx_hash           │
│ new_score       │    │ contract_address  │
│ delta           │    │ chain_id          │
│ reason          │    │ block_number      │
└─────────────────┘    │ metadata_uri      │
                       └───────────────────┘

┌─────────────────┐    ┌───────────────────┐
│  activity_log   │    │ legal_consents    │
├─────────────────┤    ├───────────────────┤
│ user_id         │ FK │ user_id           │ FK
│ action          │    │ document_type     │
│ entity          │    │ version           │
│ entity_id       │    │ ip_address        │
│ details         │    │ user_agent        │
│ ip_address      │    │ accepted_at       │
└─────────────────┘    └───────────────────┘
```

## Tabla por tabla

### 1. `users` — Cuenta y perfil

| Campo | Tipo | Notas |
|-------|------|-------|
| `id` | INT / ObjectId | PK |
| `full_name` | VARCHAR(120) | Nombre o razón social |
| `email` | VARCHAR(120) | **Único** + índice |
| `password_hash` | VARCHAR(80) | bcrypt(10) |
| `role` | ENUM | `admin` · `usuario` · `verificador` |
| `entity_type` | ENUM | `profesional` · `empresa` · `organizacion` · `particular` |
| `company_name` | VARCHAR(120) | Razón social cuando aplica |
| `document_id` | VARCHAR(40) | DNI / CUIT / NIF |
| `sector` | VARCHAR(60) | "Legal", "Finanzas", "Agro", etc. |
| `specialty` | VARCHAR(60) | Solo para verificadores |
| `kyc_status` | ENUM | `pendiente` · `verificado` · `rechazado` |
| `reputation` | DECIMAL(5,2) | 0.00 – 100.00 |
| `membership` | ENUM | `basica` · `profesional` · `premium` |
| `wallet_address` | VARCHAR(50) | EVM `0x...` |
| `status` | ENUM | `activo` · `suspendido` |
| **Marco legal** | | |
| `terms_accepted_at` | DATETIME | Fecha de aceptación T&C |
| `terms_version` | VARCHAR(20) | Ej. `2026.05` |
| `privacy_accepted_at` | DATETIME | Fecha aceptación privacidad |
| `kyc_consent` | TINYINT(1) | Consintió KYC/AML |
| **KYC detalle** | | |
| `kyc_country` | VARCHAR(80) | País del documento |
| `kyc_doc_type` | VARCHAR(40) | DNI/Pasaporte/CI/RUC/NIF/CUIT/CURP |
| `kyc_doc_number` | VARCHAR(60) | Número del documento |
| `kyc_provider` | VARCHAR(60) | `manual` / `sumsub` / `onfido` |
| `kyc_reference` | VARCHAR(80) | `MTP-KYC-XXXXXXXX` |
| `kyc_completed_at` | DATETIME | NULL si pendiente |
| `created_at` | DATETIME | DEFAULT NOW() |

**Índices**: `email`, `role+membership`, `sector`

### 2. `documents` — Archivos cargados

| Campo | Tipo | Notas |
|-------|------|-------|
| `id` | INT / ObjectId | PK |
| `user_id` | FK → `users.id` | Dueño del documento |
| `title` | VARCHAR(180) | Nombre legible |
| `doc_type` | VARCHAR(20) | `cte` / `ctpi` / `cen` / `ctk` / `contrato` / `balance` / `otro` |
| `description` | TEXT | Descripción libre |
| `file_path` | VARCHAR(255) | Ruta en el servidor |
| `file_hash` | VARCHAR(64) | **SHA-256 — índice (búsqueda pública)** |
| `file_size` | INT | Bytes |
| `status` | ENUM | `cargado` · `en_revision` · `validado` · `rechazado` |
| `ai_risk` | ENUM | `bajo` · `medio` · `alto` |
| `ai_summary` | TEXT | Resumen del motor IA |
| `assigned_to` | FK → `users.id` | Verificador asignado |
| `created_at`, `updated_at` | DATETIME | |

### 3. `validations` — Dictámenes

| Campo | Tipo | Notas |
|-------|------|-------|
| `id` | INT / ObjectId | PK |
| `document_id` | FK → `documents.id` | |
| `verifier_id` | FK → `users.id` | Quien emite |
| `val_type` | VARCHAR(30) | `juridica` · `economica` · `tecnica` · `sanitaria` · `general` |
| `result` | ENUM | `aprobado` (+8 score) · `observado` (-3) · `rechazado` (-10) |
| `score_impact` | INT | Delta aplicado al `reputation` del dueño |
| `opinion` | TEXT | Texto del dictamen |
| `created_at` | DATETIME | |

### 4. `scoring_history` — Histórico de reputación

| Campo | Tipo | Notas |
|-------|------|-------|
| `user_id` | FK → `users.id` | |
| `document_id` | FK → `documents.id` | NULL si fue manual |
| `validation_id` | FK → `validations.id` | NULL si fue manual |
| `prev_score`, `new_score`, `delta` | DECIMAL | |
| `reason` | VARCHAR(180) | Texto descriptivo |

### 5. `activity_log` — Trazabilidad estructural

| Campo | Tipo | Notas |
|-------|------|-------|
| `user_id` | FK → `users.id` | Quien realiza la acción |
| `action` | VARCHAR(40) | `register` · `login` · `upload` · `validate` · `mint` · `kyc_submit` · ... |
| `entity` | VARCHAR(30) | `user` · `document` · `validation` · `nft` |
| `entity_id` | INT / ObjectId | ID del recurso afectado |
| `details` | VARCHAR(255) | Descripción legible |
| `ip_address` | VARCHAR(45) | Para auditoría (soporta IPv6) |

### 6. `nfts` — Registro on-chain

| Campo | Tipo | Notas |
|-------|------|-------|
| `document_id` | FK → `documents.id` | Único por documento |
| `user_id` | FK → `users.id` | Dueño al momento de mintear |
| `token_id` | VARCHAR(80) | uint256 como string (precisión) |
| `tx_hash` | VARCHAR(80) | `0x...` |
| `contract_address` | VARCHAR(50) | Dirección del contrato ERC-721 |
| `chain_id` | INT | 2237 para ETTIOS |
| `block_number` | BIGINT | Bloque donde se confirmó |
| `metadata_uri` | TEXT | URL pública de metadata |
| `minted_at` | DATETIME | |

### 7. `legal_consents` — Auditoría SEPRELAD

Cada consentimiento legal queda registrado de forma **inmutable**.
Cuando un usuario se registra, se insertan 3 filas (terms, privacy, kyc).

| Campo | Tipo | Notas |
|-------|------|-------|
| `user_id` | FK → `users.id` | |
| `document_type` | ENUM | `terms` · `privacy` · `kyc` · `aml` |
| `version` | VARCHAR(20) | Ej. `2026.05` |
| `ip_address` | VARCHAR(45) | IP en el momento de aceptación |
| `user_agent` | VARCHAR(255) | Navegador / cliente |
| `accepted_at` | DATETIME | DEFAULT NOW() |

**Conservación**: 10 años desde el evento (auditoría legal SEPRELAD).

---

## Diferencias MySQL vs MongoDB

| Concepto | MySQL | MongoDB |
|----------|-------|---------|
| ID | `INT UNSIGNED AUTO_INCREMENT` | `ObjectId` (24 hex chars) |
| FK | `FOREIGN KEY ... REFERENCES` | `Schema.Types.ObjectId` + `ref:` + `.populate()` |
| ENUMs | nativo | `enum: [...]` en el schema |
| Timestamps | `DEFAULT CURRENT_TIMESTAMP` | `{ timestamps: true }` automático |
| Únicos | `UNIQUE KEY` | `unique: true` |
| Texto largo | `TEXT` | `String` sin límite |

El frontend **no nota la diferencia** — la API HTTP devuelve la misma forma.
