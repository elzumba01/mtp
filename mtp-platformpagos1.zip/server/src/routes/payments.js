/**
 * MTP PLATFORM — Endpoints de pagos.
 *
 *   POST /api/payments/redsys/create   — usuario autenticado inicia pago con tarjeta
 *   POST /api/payments/bizum/create    — usuario autenticado inicia pago Bizum
 *   POST /api/payments/notify          — webhook público que llama Redsys (sin auth, validamos firma)
 *   GET  /api/payments/mine            — lista mis pagos
 *   GET  /api/payments/:orderId        — estado de una orden
 *   GET  /api/payments/health          — diagnóstico de configuración
 */

import { Router } from 'express';
import pool from '../db.js';
import { requireAuth } from '../middleware/auth.js';
import { logActivity } from '../helpers.js';
import {
  createPayment, verifyNotification, generateOrderId, redsysHealth
} from '../payments/redsys.js';
import { createBizumPayment, bizumHealth } from '../payments/bizum.js';

const r = Router();

// Precios oficiales en céntimos (29 € = 2900, 79 € = 7900, NFT 5 € = 500)
const PRICES = {
  profesional: { amount: 2900, label: 'Membresía Profesional (mensual)' },
  premium:     { amount: 7900, label: 'Membresía Premium (mensual)'     },
  nft:         { amount: 500,  label: 'Minteo de NFT en ETTIOS'         },
};

/** GET /api/payments/health — estado de configuración */
r.get('/health', (_req, res) => {
  res.json({
    redsys: redsysHealth(),
    bizum:  bizumHealth(),
    prices: PRICES,
  });
});

/** POST /api/payments/redsys/create — inicia un pago con tarjeta */
r.post('/redsys/create', requireAuth, async (req, res, next) => {
  try {
    const { concept } = req.body || {};
    if (!PRICES[concept]) return res.status(400).json({ error: 'concept inválido (profesional/premium/nft)' });

    const orderId = generateOrderId();
    const { amount, label } = PRICES[concept];

    // Persistir la orden en estado "pendiente"
    await pool.query(
      `INSERT INTO payments (order_id, user_id, method, concept, amount, status)
       VALUES (?, ?, 'redsys', ?, ?, 'pendiente')`,
      [orderId, req.user.id, concept, amount]
    );

    const form = createPayment({
      orderId, amount, description: label, userId: String(req.user.id),
    });

    await logActivity({ userId: req.user.id, action: 'payment_init', entity: 'payment', entityId: orderId,
                        details: `Redsys · ${concept} · ${amount/100} €`, ip: req.ip });

    res.json({ order_id: orderId, method: 'redsys', amount, label, form });
  } catch (e) { next(e); }
});

/** POST /api/payments/bizum/create — inicia un pago Bizum */
r.post('/bizum/create', requireAuth, async (req, res, next) => {
  try {
    const { concept, phone } = req.body || {};
    if (!PRICES[concept]) return res.status(400).json({ error: 'concept inválido' });
    if (!phone)            return res.status(400).json({ error: 'phone es obligatorio para Bizum' });

    const orderId = generateOrderId();
    const { amount, label } = PRICES[concept];

    await pool.query(
      `INSERT INTO payments (order_id, user_id, method, concept, amount, status, phone)
       VALUES (?, ?, 'bizum', ?, ?, 'pendiente', ?)`,
      [orderId, req.user.id, concept, amount, phone]
    );

    const form = createBizumPayment({
      orderId, amount, phone, description: label, userId: String(req.user.id),
    });

    await logActivity({ userId: req.user.id, action: 'payment_init', entity: 'payment', entityId: orderId,
                        details: `Bizum · ${concept} · ${amount/100} € · tel ${form.phone_masked}`, ip: req.ip });

    res.json({ order_id: orderId, method: 'bizum', amount, label, phone: form.phone_masked, form });
  } catch (e) { next(e); }
});

/**
 * POST /api/payments/notify — webhook que Redsys golpea tras el pago.
 *
 * Redsys envía un POST con body URL-encoded conteniendo Ds_SignatureVersion,
 * Ds_MerchantParameters y Ds_Signature. Validamos la firma con la clave del
 * comercio y actualizamos el estado de la orden.
 */
r.post('/notify', async (req, res, next) => {
  try {
    const v = verifyNotification(req.body);
    if (!v.valid) {
      console.warn('  ✗ Notificación con firma inválida:', v.error);
      return res.status(400).send('FIRMA_INVALIDA');
    }

    // Actualizar la orden
    const [rows] = await pool.query('SELECT * FROM payments WHERE order_id = ? LIMIT 1', [v.orderId]);
    const order = rows[0];
    if (!order) {
      console.warn('  ✗ Orden no encontrada:', v.orderId);
      return res.status(404).send('ORDEN_NO_ENCONTRADA');
    }
    if (order.status !== 'pendiente') {
      // Ya procesada, idempotencia
      return res.send('OK');
    }

    await pool.query(
      `UPDATE payments SET status = ?, response_code = ?, authorization_code = ?, completed_at = NOW()
       WHERE order_id = ?`,
      [v.status, v.response_code, v.authorization_code, v.orderId]
    );

    // Si fue aprobado, aplicar el beneficio
    if (v.status === 'aprobado') {
      if (order.concept === 'profesional' || order.concept === 'premium') {
        await pool.query('UPDATE users SET membership = ? WHERE id = ?', [order.concept, order.user_id]);
      }
      // (para 'nft' el minteo se hace por separado desde la ficha del doc)
    }

    await logActivity({
      userId: order.user_id, action: 'payment_' + v.status,
      entity: 'payment', entityId: v.orderId,
      details: `${order.method} · ${order.concept} · ${order.amount/100} € · resp ${v.response_code}${v.authorization_code ? ' · auth ' + v.authorization_code : ''}`,
      ip: req.ip,
    });

    res.send('OK');
  } catch (e) { next(e); }
});

/** GET /api/payments/mine — lista mis pagos */
r.get('/mine', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      `SELECT order_id, method, concept, amount, status, response_code, authorization_code, phone,
              created_at, completed_at
       FROM payments WHERE user_id = ? ORDER BY created_at DESC LIMIT 50`,
      [req.user.id]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

/** GET /api/payments/:orderId — estado de una orden (chequeo desde la URL_OK del frontend) */
r.get('/:orderId', requireAuth, async (req, res, next) => {
  try {
    const [rows] = await pool.query(
      'SELECT * FROM payments WHERE order_id = ? AND user_id = ? LIMIT 1',
      [req.params.orderId, req.user.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Orden no encontrada' });
    res.json(rows[0]);
  } catch (e) { next(e); }
});

export default r;
