/**
 * MTP PLATFORM — Capa de conexión a MySQL.
 *
 * Provee:
 *   - pool      : el pool de conexiones (default export, listo para queries)
 *   - testConnection()  : ping al servidor al arrancar
 *   - getDbStatus()     : info de salud para el endpoint /api/health
 *   - withTransaction(fn) : helper para operaciones transaccionales
 */
import mysql from 'mysql2/promise';
import 'dotenv/config';

const config = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'mtp_platform',
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_POOL_SIZE || 10),
  queueLimit: 0,
  charset: 'utf8mb4_unicode_ci',
  dateStrings: false,
  // Reconexión y robustez en producción
  enableKeepAlive: true,
  keepAliveInitialDelay: 10_000,
  // Mejores errores SQL
  multipleStatements: false,
  timezone: 'Z',
};

const pool = mysql.createPool(config);

// Logs útiles del ciclo de vida del pool
pool.on('connection', (conn) => {
  if (process.env.NODE_ENV !== 'production') {
    console.log(`  ↳ MySQL conexión #${conn.threadId} establecida`);
  }
});
pool.on('enqueue', () => {
  console.warn('  ⚠ Pool MySQL en cola — todas las conexiones ocupadas');
});

/**
 * Hace un SELECT 1 al arrancar para confirmar que la DB existe y responde.
 * Si falla, imprime un diagnóstico claro y sale con código 1.
 */
export async function testConnection() {
  try {
    const conn = await pool.getConnection();
    const [rows] = await conn.query('SELECT 1 AS ok, VERSION() AS version, NOW() AS server_time');
    conn.release();
    console.log(`✓ MySQL conectado en ${config.host}:${config.port}/${config.database}`);
    console.log(`  Versión servidor: ${rows[0].version}`);
    return rows[0];
  } catch (err) {
    console.error('\n✗ Fallo al conectar a MySQL:');
    console.error(`  Host: ${config.host}:${config.port}`);
    console.error(`  DB:   ${config.database}`);
    console.error(`  User: ${config.user}`);
    console.error(`  Error: ${err.code || ''} ${err.message}`);
    if (err.code === 'ECONNREFUSED') {
      console.error('\n  → Solución: verificá que MySQL esté corriendo (en WAMP, prendelo desde el panel).');
    } else if (err.code === 'ER_ACCESS_DENIED_ERROR') {
      console.error('\n  → Solución: revisá DB_USER y DB_PASSWORD en .env.');
    } else if (err.code === 'ER_BAD_DB_ERROR') {
      console.error('\n  → Solución: corré "npm run init-db" para crear la base.');
    }
    throw err;
  }
}

/**
 * Devuelve un objeto con el estado de la DB para el endpoint /api/health.
 */
export async function getDbStatus() {
  try {
    const [rows] = await pool.query(
      `SELECT
         (SELECT COUNT(*) FROM users)              AS users,
         (SELECT COUNT(*) FROM documents)          AS documents,
         (SELECT COUNT(*) FROM validations)        AS validations,
         (SELECT COUNT(*) FROM nfts)               AS nfts,
         (SELECT COUNT(*) FROM legal_consents)     AS consents,
         (SELECT COUNT(*) FROM activity_log)       AS activity`
    );
    return {
      ok: true,
      host: config.host,
      database: config.database,
      counts: rows[0],
    };
  } catch (err) {
    return { ok: false, error: err.message, code: err.code };
  }
}

/**
 * Helper para correr varias queries dentro de una transacción atómica.
 * Devuelve lo que devuelva la función `fn(conn)`. Hace rollback en error.
 *
 * Ejemplo:
 *   await withTransaction(async (conn) => {
 *     await conn.query('UPDATE users SET … WHERE id = ?', [id]);
 *     await conn.query('INSERT INTO scoring_history …', [...]);
 *   });
 */
export async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

/**
 * Convierte errores SQL crudos en mensajes amigables al usuario final.
 * Lo usa el handler global de errores en index.js.
 */
export function friendlySqlError(err) {
  switch (err.code) {
    case 'ER_DUP_ENTRY':
      return { status: 409, message: 'Ya existe un registro con esos datos' };
    case 'ER_NO_REFERENCED_ROW_2':
    case 'ER_NO_REFERENCED_ROW':
      return { status: 400, message: 'Referencia inválida — el registro relacionado no existe' };
    case 'ER_ROW_IS_REFERENCED_2':
    case 'ER_ROW_IS_REFERENCED':
      return { status: 409, message: 'No se puede eliminar — el registro está siendo usado' };
    case 'ER_DATA_TOO_LONG':
      return { status: 400, message: 'Uno de los campos excede el largo permitido' };
    case 'ER_BAD_NULL_ERROR':
      return { status: 400, message: 'Falta un campo obligatorio' };
    case 'ER_DATA_OUT_OF_RANGE':
      return { status: 400, message: 'Valor fuera de rango' };
    case 'ECONNREFUSED':
    case 'PROTOCOL_CONNECTION_LOST':
      return { status: 503, message: 'Servicio de base de datos no disponible' };
    default:
      return null;
  }
}

export default pool;
