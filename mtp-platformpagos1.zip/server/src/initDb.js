/**
 * MTP PLATFORM — Inicializador de base de datos.
 * Crea la base si no existe, ejecuta el schema y siembra datos demo.
 * Uso:  node src/initDb.js
 */
import fs from 'node:fs';
import path from 'node:path';
import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';
import 'dotenv/config';

const cfg = {
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  multipleStatements: true,
  charset: 'utf8mb4_unicode_ci',
};
const dbName = process.env.DB_NAME || 'mtp_platform';

async function run() {
  const root = await mysql.createConnection(cfg);
  console.log('✓ Conectado a MySQL en', cfg.host);

  await root.query(
    `CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
  );
  await root.query(`USE \`${dbName}\``);
  console.log(`✓ Base \`${dbName}\` lista`);

  const schemaPath = path.resolve('./sql/schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  await root.query(schema);
  console.log('✓ Schema aplicado');

  // Re-seed (truncate seguro)
  await root.query('SET FOREIGN_KEY_CHECKS = 0');
  for (const t of ['payments','legal_consents','nfts','scoring_history','validations','documents','activity_log','users']) {
    await root.query(`TRUNCATE TABLE \`${t}\``);
  }
  await root.query('SET FOREIGN_KEY_CHECKS = 1');

  const hash = await bcrypt.hash('mtp1234', 10);
  const users = [
    // [full_name, email, role, entity_type, company, doc_id, sector, specialty, kyc, reputation, membership, wallet]
    ['Administrador MTP',    'admin@mtp.test',    'admin',       'organizacion','Aston Mining S.L.','23374177',     'Tecnología',  null,       'verificado',100.0,'premium',     '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1'],
    ['Estudio Vega & Asoc.', 'empresa@mtp.test',  'usuario',     'empresa',     'Vega & Asociados','30-71234567-8', 'Inmobiliario',null,       'verificado', 62.0,'profesional', '0x9c4afE3e2d8c12bC4A7e9F5cD83b6E1aF24Bf2E1'],
    ['Bruno Acosta',         'usuario@mtp.test',  'usuario',     'profesional', null,              '28999111',      'Agro',        null,       'pendiente',  50.0,'basica',      null],
    ['Dra. Lucía Ferreyra',  'abogada@mtp.test',  'verificador', 'profesional', null,              '27888222',      'Legal',       'abogado',  'verificado', 88.0,'premium',     '0xc12a4f7e9b3d2c8a1f5e6d4b7c9a8e2f3d1b5c7a'],
    ['Cont. Marco Salinas',  'contador@mtp.test', 'verificador', 'profesional', null,              '20777333',      'Finanzas',    'contador', 'verificado', 91.0,'profesional', null],
  ];
  for (const u of users) {
    const [ins] = await root.query(
      `INSERT INTO users (full_name,email,password_hash,role,entity_type,company_name,document_id,sector,specialty,kyc_status,reputation,membership,wallet_address,
                         terms_accepted_at,terms_version,privacy_accepted_at,kyc_consent)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),'2026.05',NOW(),1)`,
      [u[0], u[1], hash, u[2], u[3], u[4], u[5], u[6], u[7], u[8], u[9], u[10], u[11]]
    );
    const uid = ins.insertId;
    // Log de los 3 consentimientos (auditoría SEPRELAD)
    await root.query(
      `INSERT INTO legal_consents (user_id, document_type, version, ip_address, user_agent)
       VALUES (?, 'terms',   '2026.05', '127.0.0.1', 'seed/initDb'),
              (?, 'privacy', '2026.05', '127.0.0.1', 'seed/initDb'),
              (?, 'kyc',     '2026.05', '127.0.0.1', 'seed/initDb')`,
      [uid, uid, uid]
    );
  }
  console.log('✓ 5 usuarios demo creados (contraseña: mtp1234) — con consentimientos legales registrados');

  // ─────────────────────────────────────────────────────────────
  //  Documentos demo
  // ─────────────────────────────────────────────────────────────
  const [[empresa]]  = await root.query("SELECT id FROM users WHERE email='empresa@mtp.test'");
  const [[abogada]]  = await root.query("SELECT id FROM users WHERE email='abogada@mtp.test'");
  const [[contador]] = await root.query("SELECT id FROM users WHERE email='contador@mtp.test'");
  const [[usuario]]  = await root.query("SELECT id FROM users WHERE email='usuario@mtp.test'");

  // Documento 1 — contrato validado por Abogada, listo para mintear
  await root.query(
    `INSERT INTO documents (user_id,title,doc_type,description,file_hash,status,ai_risk,ai_summary,assigned_to)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [empresa.id,
     'Contrato de fideicomiso inmobiliario - Torre Norte',
     'cen',
     'Estructura de fideicomiso para 42 unidades funcionales en AMBA. Cláusulas de cesión y prelación auditadas.',
     '3f8b9e2c47a9d18e1f8a72b6c9d4e5a8b3c1f9e2d6a4b8c7f5e3d2a1b9c8e7f6a',
     'validado', 'bajo', 'El motor IA no detectó inconsistencias relevantes.', abogada.id]
  );
  const [[doc1]] = await root.query('SELECT LAST_INSERT_ID() AS id');
  await root.query(
    `INSERT INTO validations (document_id, verifier_id, val_type, result, score_impact, opinion)
     VALUES (?,?,?,?,?,?)`,
    [doc1.id, abogada.id, 'juridica', 'aprobado', 8,
     'Estructura jurídica adecuada y conforme a la normativa. Cláusulas de prelación claras.']
  );

  // Documento 2 — balance validado por Contador
  await root.query(
    `INSERT INTO documents (user_id,title,doc_type,description,file_hash,status,ai_risk,ai_summary,assigned_to)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [empresa.id,
     'Balance contable Q4 2025 - Vega & Asociados',
     'cte',
     'Estados financieros del cuarto trimestre auditados conforme normas IFRS.',
     'c12a4f7e9b3d2c8a1f5e6d4b7c9a8e2f3d1b5c7a9e6f4d2b8c1a3f7e5d9b6c4a',
     'validado', 'bajo', 'Coherencia interna correcta. Métricas dentro de rangos esperados.', contador.id]
  );
  const [[doc2]] = await root.query('SELECT LAST_INSERT_ID() AS id');
  await root.query(
    `INSERT INTO validations (document_id, verifier_id, val_type, result, score_impact, opinion)
     VALUES (?,?,?,?,?,?)`,
    [doc2.id, contador.id, 'economica', 'aprobado', 8,
     'Balance conforme a normas IFRS. Sin observaciones relevantes.']
  );

  // Documento 3 — del usuario básico, en cola de validación
  await root.query(
    `INSERT INTO documents (user_id,title,doc_type,description,status,ai_risk,ai_summary)
     VALUES (?,?,?,?,?,?,?)`,
    [usuario.id,
     'Certificación de feedlot ganadero — 200 cabezas Brangus',
     'ctk',
     'Documentación de trazabilidad de feedlot para tokenización ganadera.',
     'cargado', 'medio', 'Documento requiere validación profesional de un veterinario.']
  );

  console.log('✓ 3 documentos demo creados (2 validados + 1 en cola)');

  // ─────────────────────────────────────────────────────────────
  //  Log de actividad inicial
  // ─────────────────────────────────────────────────────────────
  await root.query(
    `INSERT INTO activity_log (user_id, action, entity, entity_id, details, ip_address)
     VALUES (?, 'seed', 'system', NULL, 'Inicialización de base de datos con datos demo', '127.0.0.1')`,
    [1]
  );
  console.log('✓ Log de actividad inicializado');

  await root.end();
  console.log('\n▶ Listo. Iniciá el servidor con:  npm start');
  console.log('  Logins demo (todos contraseña mtp1234):');
  console.log('   admin@mtp.test  ·  empresa@mtp.test  ·  usuario@mtp.test  ·  abogada@mtp.test  ·  contador@mtp.test');
}

run().catch(err => { console.error('✗ Init falló:', err.message); process.exit(1); });
