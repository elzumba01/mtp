/**
 * MTP PLATFORM — Capa de conexión a MongoDB.
 *
 * Provee:
 *   - connectMongo()    : abre la conexión y la mantiene viva
 *   - getDbStatus()     : info de salud para el endpoint /api/health
 *   - withTransaction() : helper para operaciones transaccionales (requiere replica set)
 *   - friendlyMongoError() : convierte códigos crudos en mensajes amigables
 */
import mongoose from 'mongoose';
import 'dotenv/config';

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/mtp_platform';

// Eventos del ciclo de vida
mongoose.connection.on('connected', () => {
  console.log(`✓ MongoDB conectado en ${maskUri(MONGO_URI)}`);
});
mongoose.connection.on('error', (err) => {
  console.error('✗ MongoDB error:', err.message);
});
mongoose.connection.on('disconnected', () => {
  console.warn('⚠ MongoDB desconectado');
});

function maskUri(uri) {
  // Oculta la password si viene en la URI: mongodb+srv://user:pass@... -> mongodb+srv://user:***@...
  return uri.replace(/:\/\/([^:]+):([^@]+)@/, '://$1:***@');
}

/**
 * Conecta a Mongo. Si falla, imprime diagnóstico claro y sale con código 1.
 */
export async function connectMongo() {
  try {
    await mongoose.connect(MONGO_URI, {
      serverSelectionTimeoutMS: 6000,
      socketTimeoutMS: 45000,
      maxPoolSize: Number(process.env.MONGO_POOL_SIZE || 20),
    });
    return mongoose.connection;
  } catch (err) {
    console.error('\n✗ Fallo al conectar a MongoDB:');
    console.error(`  URI: ${maskUri(MONGO_URI)}`);
    console.error(`  Error: ${err.code || ''} ${err.message}`);
    if (err.message.includes('ECONNREFUSED')) {
      console.error('\n  → Solución: verificá que MongoDB esté corriendo.');
      console.error('     - Local Linux: sudo systemctl start mongod');
      console.error('     - Local macOS: brew services start mongodb-community');
      console.error('     - Windows:    arrancá el servicio MongoDB Server.');
    } else if (err.message.includes('authentication failed')) {
      console.error('\n  → Solución: revisá usuario y password en MONGO_URI.');
    } else if (err.message.includes('ENOTFOUND')) {
      console.error('\n  → Solución: el host del cluster Atlas no resuelve. Revisá la URI.');
    }
    throw err;
  }
}

/**
 * Devuelve el estado de la DB y conteos por colección para /api/health.
 */
export async function getDbStatus() {
  try {
    const conn = mongoose.connection;
    if (conn.readyState !== 1) {
      return { ok: false, state: stateLabel(conn.readyState) };
    }
    const [users, documents, validations, nfts, consents, activity] = await Promise.all([
      conn.db.collection('users').countDocuments(),
      conn.db.collection('documents').countDocuments(),
      conn.db.collection('validations').countDocuments(),
      conn.db.collection('nfts').countDocuments(),
      conn.db.collection('legal_consents').countDocuments(),
      conn.db.collection('activity_log').countDocuments(),
    ]);
    return {
      ok: true,
      host: conn.host,
      database: conn.name,
      state: 'connected',
      counts: { users, documents, validations, nfts, consents, activity },
    };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

function stateLabel(s) {
  return ['disconnected','connected','connecting','disconnecting'][s] || 'unknown';
}

/**
 * Helper transaccional. Requiere replica set (Atlas siempre, local con --replSet).
 * Si la deployment es standalone, ejecuta la función sin transacción.
 *
 * Uso:
 *   await withTransaction(async (session) => {
 *     await User.updateOne({ _id }, { $inc: { reputation: 5 } }, { session });
 *     await ScoringHistory.create([{ ... }], { session });
 *   });
 */
export async function withTransaction(fn) {
  const session = await mongoose.startSession();
  try {
    let result;
    await session.withTransaction(async () => {
      result = await fn(session);
    });
    return result;
  } catch (err) {
    // Si Mongo es standalone, las transacciones lanzan código 20.
    // Hacemos fallback ejecutando la función sin sesión.
    if (err.code === 20 || /Transaction numbers are only allowed/.test(err.message)) {
      console.warn('  ⚠ Mongo standalone — ejecutando sin transacción');
      return fn(null);
    }
    throw err;
  } finally {
    session.endSession();
  }
}

/**
 * Convierte errores de Mongoose en mensajes HTTP amigables.
 */
export function friendlyMongoError(err) {
  // Validación de schema (campos requeridos, formato, etc.)
  if (err.name === 'ValidationError') {
    const fields = Object.keys(err.errors || {}).join(', ');
    return { status: 400, message: `Datos inválidos: ${fields}` };
  }
  // Cast (tipo equivocado, ObjectId malformado)
  if (err.name === 'CastError') {
    return { status: 400, message: `Identificador inválido: ${err.path}` };
  }
  // Duplicado (índice único violado)
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue || {})[0] || 'campo';
    return { status: 409, message: `Ya existe un registro con ese ${field}` };
  }
  // Conexión caída
  if (err.name === 'MongoNetworkError') {
    return { status: 503, message: 'Servicio de base de datos no disponible' };
  }
  // Documento no encontrado
  if (err.name === 'DocumentNotFoundError') {
    return { status: 404, message: 'Registro no encontrado' };
  }
  return null;
}

export default mongoose;
