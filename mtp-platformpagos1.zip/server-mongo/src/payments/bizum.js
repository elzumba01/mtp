/**
 * MTP PLATFORM — Integración con Bizum.
 *
 * Bizum corre encima de Redsys. La diferencia es que se agrega
 * el parámetro Ds_Merchant_PayMethods = "z" (forzar Bizum) y el
 * usuario paga con su número de teléfono asociado a Bizum, recibiendo
 * la clave de confirmación por SMS.
 *
 * Requiere que tu contrato con CaixaBank tenga Bizum habilitado.
 */

import crypto from 'node:crypto';
import { generateOrderId } from './redsys.js';

const REDSYS_URLS = {
  test:       'https://sis-t.redsys.es:25443/sis/realizarPago',
  production: 'https://sis.redsys.es/sis/realizarPago',
};

const ENV = process.env.REDSYS_ENVIRONMENT || 'test';
const MERCHANT_CODE = process.env.REDSYS_MERCHANT_CODE || '';
const TERMINAL = process.env.REDSYS_TERMINAL || '1';
const CURRENCY = process.env.REDSYS_CURRENCY || '978';
const SECRET_KEY = process.env.REDSYS_SECRET_KEY || '';
const BIZUM_ENABLED = process.env.BIZUM_ENABLED === 'true';

function tripleDesEncrypt(message, key) {
  const iv = Buffer.alloc(8, 0);
  const cipher = crypto.createCipheriv('des-ede3-cbc', Buffer.from(key, 'base64'), iv);
  cipher.setAutoPadding(false);
  const buf = Buffer.from(message, 'utf8');
  const padded = Buffer.concat([buf, Buffer.alloc(8 - (buf.length % 8 || 8), 0)]);
  return Buffer.concat([cipher.update(padded), cipher.final()]);
}

function sign(payloadBase64, orderId) {
  const derivedKey = tripleDesEncrypt(orderId, SECRET_KEY);
  return crypto.createHmac('sha256', derivedKey).update(payloadBase64).digest('base64');
}

export function bizumHealth() {
  return {
    configured: !!(MERCHANT_CODE && SECRET_KEY),
    enabled: BIZUM_ENABLED,
    environment: ENV,
  };
}

/**
 * Genera el payload para un pago vía Bizum (idéntico a Redsys pero forzando paymethod "z").
 */
export function createBizumPayment({ orderId, amount, phone, description, userId }) {
  if (!MERCHANT_CODE || !SECRET_KEY) {
    throw new Error('Bizum no está configurado. Faltan credenciales Redsys.');
  }
  if (!BIZUM_ENABLED) {
    throw new Error('Bizum no está habilitado en este contrato de CaixaBank.');
  }
  if (!phone) throw new Error('Para Bizum, el número de teléfono es obligatorio');
  if (!/^[+]?[0-9]{9,15}$/.test(phone.replace(/\s/g, ''))) {
    throw new Error('Formato de teléfono inválido. Debe ser un número español como +34600123456 o 600123456.');
  }

  const payload = {
    DS_MERCHANT_AMOUNT:           String(amount),
    DS_MERCHANT_ORDER:            orderId || generateOrderId(),
    DS_MERCHANT_MERCHANTCODE:     MERCHANT_CODE,
    DS_MERCHANT_CURRENCY:         CURRENCY,
    DS_MERCHANT_TRANSACTIONTYPE:  '0',
    DS_MERCHANT_TERMINAL:         TERMINAL,
    DS_MERCHANT_PAYMETHODS:       'z',                     // ← clave que activa Bizum
    DS_MERCHANT_P2F:              phone.replace(/[\s+]/g, ''),   // teléfono sin espacios ni +
    DS_MERCHANT_MERCHANTURL:      process.env.REDSYS_NOTIFICATION_URL || '',
    DS_MERCHANT_URLOK:            process.env.REDSYS_OK_URL || '',
    DS_MERCHANT_URLKO:            process.env.REDSYS_KO_URL || '',
    DS_MERCHANT_PRODUCTDESCRIPTION: description || 'MTP Platform — Bizum',
    DS_MERCHANT_TITULAR:          userId || 'usuario',
    DS_MERCHANT_CONSUMERLANGUAGE: '001',
  };

  const payloadBase64 = Buffer.from(JSON.stringify(payload)).toString('base64');
  const signature = sign(payloadBase64, payload.DS_MERCHANT_ORDER);

  return {
    url: REDSYS_URLS[ENV],
    Ds_SignatureVersion: 'HMAC_SHA256_V1',
    Ds_MerchantParameters: payloadBase64,
    Ds_Signature: signature,
    payment_method: 'bizum',
    phone_masked: phone.slice(0, 3) + '****' + phone.slice(-3),
  };
}
