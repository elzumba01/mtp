/**
 * MTP PLATFORM — Integración con Redsys / CaixaBank (Cyberpac).
 *
 * Redsys es la plataforma TPV virtual que usan CaixaBank y la mayoría
 * de bancos españoles. El flujo es:
 *
 *   1. El servidor arma un "payload" con los datos del pago
 *   2. Codifica el payload en base64
 *   3. Firma el payload con la clave del comercio (HMAC SHA-256 con 3DES)
 *   4. El frontend envía un FORM por POST a la URL de Redsys con 3 campos:
 *        - Ds_SignatureVersion: "HMAC_SHA256_V1"
 *        - Ds_MerchantParameters: payload en base64
 *        - Ds_Signature: la firma calculada
 *   5. Redsys procesa el pago y redirige al usuario a la URL de éxito/fallo
 *   6. Redsys también notifica al backend por HTTP POST (webhook)
 *
 * Credenciales del .env:
 *   REDSYS_MERCHANT_CODE    — código FUC que te da CaixaBank
 *   REDSYS_TERMINAL         — número de terminal (suele ser "1")
 *   REDSYS_CURRENCY         — "978" para EUR
 *   REDSYS_SECRET_KEY       — clave del comercio (base64, te la da CaixaBank)
 *   REDSYS_ENVIRONMENT      — "test" o "production"
 *   REDSYS_OK_URL           — donde Redsys redirige tras pago exitoso
 *   REDSYS_KO_URL           — donde Redsys redirige tras pago fallido
 *   REDSYS_NOTIFICATION_URL — endpoint del backend para webhook
 */

import crypto from 'node:crypto';

const REDSYS_URLS = {
  test:       'https://sis-t.redsys.es:25443/sis/realizarPago',
  production: 'https://sis.redsys.es/sis/realizarPago',
};

const ENV = process.env.REDSYS_ENVIRONMENT || 'test';
const MERCHANT_CODE = process.env.REDSYS_MERCHANT_CODE || '';
const TERMINAL = process.env.REDSYS_TERMINAL || '1';
const CURRENCY = process.env.REDSYS_CURRENCY || '978';
const SECRET_KEY = process.env.REDSYS_SECRET_KEY || '';

/**
 * Devuelve el estado de configuración para /api/health.
 */
export function redsysHealth() {
  return {
    configured: !!(MERCHANT_CODE && SECRET_KEY),
    environment: ENV,
    endpoint: REDSYS_URLS[ENV],
    merchant_code: MERCHANT_CODE ? `***${MERCHANT_CODE.slice(-4)}` : null,
  };
}

/**
 * Genera un order_id único de 12 caracteres (Redsys exige 4 dígitos + 8 alfanuméricos).
 */
export function generateOrderId() {
  const ts = Date.now().toString().slice(-4);
  const rnd = crypto.randomBytes(4).toString('hex').toUpperCase();
  return ts + rnd;
}

/**
 * Cifra con 3DES en modo CBC con IV de ceros (lo que pide Redsys).
 */
function tripleDesEncrypt(message, key) {
  const iv = Buffer.alloc(8, 0);
  const cipher = crypto.createCipheriv('des-ede3-cbc', Buffer.from(key, 'base64'), iv);
  cipher.setAutoPadding(false);
  // Padding zero hasta múltiplo de 8 bytes
  const buf = Buffer.from(message, 'utf8');
  const padded = Buffer.concat([buf, Buffer.alloc(8 - (buf.length % 8 || 8), 0)]);
  return Buffer.concat([cipher.update(padded), cipher.final()]);
}

/**
 * Genera la firma HMAC SHA-256 que Redsys espera.
 */
function sign(payloadBase64, orderId) {
  const derivedKey = tripleDesEncrypt(orderId, SECRET_KEY);
  const hmac = crypto.createHmac('sha256', derivedKey);
  hmac.update(payloadBase64);
  return hmac.digest('base64');
}

/**
 * Genera los 3 campos que el frontend POSTea a Redsys.
 *
 * @param {Object} params
 * @param {string} params.orderId   — ID único de la orden (12 chars)
 * @param {number} params.amount    — monto en céntimos (29 € = 2900)
 * @param {string} params.description — descripción visible del producto
 * @param {string} params.userId    — ID del usuario que paga
 */
export function createPayment({ orderId, amount, description, userId }) {
  if (!MERCHANT_CODE || !SECRET_KEY) {
    throw new Error('Redsys no está configurado. Faltan REDSYS_MERCHANT_CODE o REDSYS_SECRET_KEY en el .env.');
  }
  if (!orderId || !amount) throw new Error('orderId y amount son obligatorios');

  const payload = {
    DS_MERCHANT_AMOUNT:           String(amount),          // en céntimos
    DS_MERCHANT_ORDER:            orderId,
    DS_MERCHANT_MERCHANTCODE:     MERCHANT_CODE,
    DS_MERCHANT_CURRENCY:         CURRENCY,
    DS_MERCHANT_TRANSACTIONTYPE:  '0',                     // 0 = autorización normal
    DS_MERCHANT_TERMINAL:         TERMINAL,
    DS_MERCHANT_MERCHANTURL:      process.env.REDSYS_NOTIFICATION_URL || '',
    DS_MERCHANT_URLOK:            process.env.REDSYS_OK_URL || '',
    DS_MERCHANT_URLKO:            process.env.REDSYS_KO_URL || '',
    DS_MERCHANT_PRODUCTDESCRIPTION: description || 'MTP Platform',
    DS_MERCHANT_TITULAR:          userId || 'usuario',
    DS_MERCHANT_CONSUMERLANGUAGE: '001',                   // 001 = español
  };

  const payloadBase64 = Buffer.from(JSON.stringify(payload)).toString('base64');
  const signature = sign(payloadBase64, orderId);

  return {
    url: REDSYS_URLS[ENV],
    Ds_SignatureVersion: 'HMAC_SHA256_V1',
    Ds_MerchantParameters: payloadBase64,
    Ds_Signature: signature,
  };
}

/**
 * Valida la firma de una notificación HTTP entrante (webhook).
 * Redsys envía: Ds_SignatureVersion, Ds_MerchantParameters, Ds_Signature.
 * Tenemos que recalcular la firma y compararla.
 */
export function verifyNotification(body) {
  const params = body.Ds_MerchantParameters;
  const receivedSig = body.Ds_Signature;
  if (!params || !receivedSig) return { valid: false, error: 'Faltan parámetros' };

  const decoded = JSON.parse(Buffer.from(params, 'base64').toString('utf8'));
  const orderId = decoded.Ds_Order || decoded.DS_MERCHANT_ORDER;
  if (!orderId) return { valid: false, error: 'Orden no encontrada en payload' };

  // La firma esperada usa la URL-safe variant (- en vez de +, _ en vez de /)
  const expectedSig = sign(params, orderId)
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
  const incomingSig = receivedSig.replace(/\+/g, '-').replace(/\//g, '_');

  const valid = expectedSig === incomingSig;
  const responseCode = Number(decoded.Ds_Response || 9999);
  // Códigos 0-99 = autorizado · 9xxx = denegado
  const status = valid && responseCode < 100 ? 'aprobado' : valid ? 'denegado' : 'firma_invalida';

  return {
    valid,
    status,
    orderId,
    amount: Number(decoded.Ds_Amount || 0),
    response_code: responseCode,
    authorization_code: decoded.Ds_AuthorisationCode || null,
    decoded,
  };
}
