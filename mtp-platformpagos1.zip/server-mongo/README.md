# MTP Platform — Backend (MongoDB)

Backend alternativo del MTP Platform con **MongoDB + Mongoose** en lugar de MySQL.
Mismos endpoints, misma lógica de negocio, mismo contrato HTTP con el frontend React.

## ⚡ Diferencias clave con la versión MySQL

| Aspecto | MySQL (`server/`) | MongoDB (`server-mongo/`) |
|---------|-------------------|---------------------------|
| **Driver** | `mysql2/promise` | `mongoose` 8.x |
| **Estructura** | 7 tablas con FK | 7 colecciones con refs |
| **Schema** | `sql/schema.sql` (declarativo) | `src/models/index.js` (Mongoose) |
| **Init** | `npm run init-db` (crea base + schema + seed) | `npm run init-db` (crea índices + seed) |
| **IDs** | `INT UNSIGNED AUTO_INCREMENT` | `ObjectId` (24 hex chars) |
| **Transacciones** | nativas | requieren replica set (auto-fallback a single ops) |
| **Búsqueda libre** | `LIKE %x%` lento | `text index` o regex con índices |

## 🚀 Setup

### 1) Levantá MongoDB

**Opción A — Local (Ubuntu/Debian):**
```bash
sudo apt install mongodb-org
sudo systemctl start mongod
```

**Opción B — Local (macOS):**
```bash
brew install mongodb-community
brew services start mongodb-community
```

**Opción C — Local (Windows / WAMP):**
Bajá el instalador desde https://www.mongodb.com/try/download/community y arrancá el servicio.

**Opción D — MongoDB Atlas (cloud, recomendado para producción):**
- Creá un cluster gratuito en https://www.mongodb.com/cloud/atlas
- Whitelisteá tu IP
- Copiá la connection string al `.env`

### 2) Configurá

```bash
cd server-mongo
npm install
cp .env.example .env
# editá .env con tu MONGO_URI
```

### 3) Inicializá + arrancá

```bash
npm run init-db   # crea índices + seed con 5 users, 3 docs, 2 validations, 15 consents
npm run dev       # arranca en http://localhost:4000
```

## 📊 Las 7 colecciones

| Colección | Modelo | Reemplaza tabla SQL |
|-----------|--------|---------------------|
| `users` | `User` | `users` |
| `documents` | `Document` | `documents` |
| `validations` | `Validation` | `validations` |
| `scoring_history` | `ScoringHistory` | `scoring_history` |
| `activity_log` | `ActivityLog` | `activity_log` |
| `nfts` | `Nft` | `nfts` |
| `legal_consents` | `LegalConsent` | `legal_consents` |

### Diferencias en relaciones

En SQL: `documents.user_id INT REFERENCES users(id)`
En Mongo:
```js
user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true }
```

Para "joinar" usás `.populate('user_id', 'full_name email')` que rellena automáticamente.

## 🛠 Troubleshooting

| Error | Solución |
|-------|----------|
| `ECONNREFUSED 27017` | MongoDB no está corriendo. `sudo systemctl start mongod` |
| `authentication failed` | Revisá usuario/password en `MONGO_URI` |
| `ENOTFOUND cluster0.xxxxx.mongodb.net` | URI de Atlas mal copiada |
| `Transaction numbers are only allowed` | Sos standalone, no replica set. El código hace fallback automáticamente. |

## 🔁 Migrar desde MySQL

Si ya tenés datos en MySQL y querés pasarlos a Mongo, lo más simple es:

1. Levantá ambos servers (MySQL en `:4000`, Mongo en otro puerto temporalmente)
2. Usá `mongoimport` o un script ad-hoc para volcar cada tabla a su colección
3. Actualizá el frontend para apuntar al Mongo (`vite.config.js` proxy)

El frontend **no requiere ningún cambio** — los endpoints HTTP devuelven exactamente la misma forma.

## 📦 Stack

- Node 22 · Express 4.21 · Mongoose 8.8
- bcryptjs · jsonwebtoken · multer · ethers.js 6.13
- ETTIOS Blockchain Chain ID 2237
