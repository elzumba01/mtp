# Descripción

<!-- Qué resuelve este PR? Si cierra un issue, agregá "Closes #N" -->

## Tipo de cambio

<!-- Marcá con [x] lo que corresponda -->

- [ ] 🐛 Bug fix (cambio que arregla un issue, sin romper compatibilidad)
- [ ] ✨ Nueva feature (cambio que agrega funcionalidad, sin romper compatibilidad)
- [ ] 💥 Breaking change (cambio que rompe compatibilidad)
- [ ] 📝 Documentación
- [ ] ♻️ Refactor (sin cambios funcionales)
- [ ] 🎨 UI / estilos
- [ ] ⚡️ Performance

## Cómo se probó

<!-- Pasos concretos. Si tocaste backend, mencioná contra qué DB lo probaste -->

- [ ] Build del frontend pasa (`cd client && npm run build`)
- [ ] Backend MySQL arranca y `/api/health` devuelve `ok: true`
- [ ] Backend Mongo arranca y `/api/health` devuelve `ok: true`
- [ ] Smart contract compila con solc 0.8.20
- [ ] El CI de GitHub Actions pasa

## Screenshots

<!-- Si tocaste UI, agregá antes/después -->

## Checklist

- [ ] Sigo el estilo de código del proyecto (2 espacios, ESM, comentarios en español)
- [ ] No incluí archivos `.env`, claves privadas ni secretos
- [ ] Actualicé documentación si hacía falta
- [ ] El contrato HTTP API sigue siendo igual o documenté los cambios
- [ ] Probé con los usuarios demo del seed (`mtp1234`)
