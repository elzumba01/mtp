# Contribuir a MTP Platform

¡Gracias por interesarte en aportar! 🎉

## 🐛 Reportar un bug

1. Buscá primero en [Issues](../../issues) si ya existe.
2. Si no, abrí uno con el template "Bug report" — incluí:
   - Pasos para reproducirlo
   - Versión de Node y de DB
   - Logs del servidor (anonimizados)

## 💡 Proponer una feature

Abrí un Issue con el template "Feature request" y contá:
- Qué problema resuelve
- Cómo te imaginás la API o UI
- Si estás dispuesto a implementarla

## 🛠 Setup local

```bash
git clone https://github.com/TU_USUARIO/mtp-platform.git
cd mtp-platform

# Backend
cd server      # o server-mongo
npm install
cp .env.example .env
npm run init-db
npm run dev

# Frontend (en otra terminal)
cd ../client
npm install
npm run dev
```

## 📝 Estilo de código

- **JavaScript moderno** (ESM, async/await, sin `var`)
- **Indentación**: 2 espacios
- **Comillas**: simples para JS, dobles para JSX
- **Nombres**:
  - Variables y funciones: `camelCase`
  - Componentes React: `PascalCase`
  - Constantes globales: `UPPER_SNAKE_CASE`
- Comentarios en español, código en inglés (variables, funciones)
- Sin dependencias innecesarias — preferí soluciones nativas

## 🔀 Pull Requests

1. Hacé fork del repo
2. Creá una rama: `git checkout -b feature/mi-mejora`
3. Commit con mensaje descriptivo (preferentemente convencional: `feat:`, `fix:`, `docs:`, `refactor:`)
4. Antes de pushear, asegurate que el build pasa:
   ```bash
   cd client && npm run build
   cd ../server && node --check src/index.js
   ```
5. Pushá: `git push origin feature/mi-mejora`
6. Abrí el PR desde GitHub

### Checklist del PR

- [ ] El código compila sin warnings
- [ ] Se probaron los cambios localmente
- [ ] Se actualizó documentación si era necesario
- [ ] No se incluyen archivos `.env` ni secretos
- [ ] El frontend sigue funcionando con ambos backends (MySQL y Mongo) si tocaste API

## 🚨 Seguridad

Si encontrás una vulnerabilidad **no la publiques en Issues**. Seguí el procedimiento de [SECURITY.md](SECURITY.md).

## 🙏 Código de conducta

Sé respetuoso con el resto de contributors. Críticas técnicas sí, ataques personales no. Si algo se sale de tono, los maintainers pueden moderar.

---

¡Gracias por construir esto con nosotros! 🚀
