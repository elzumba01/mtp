# MTP Platform

> **Infraestructura Global de Economía Verificable** — IA + verificadores humanos + escribanos digitales + NFTs en ETTIOS Blockchain.

[![Node.js](https://img.shields.io/badge/Node.js-22%2B-339933?logo=node.js&logoColor=white)](https://nodejs.org/)
[![React](https://img.shields.io/badge/React-18.3-61DAFB?logo=react&logoColor=black)](https://react.dev/)
[![License](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![Status](https://img.shields.io/badge/status-beta-orange)]()

Una plataforma para que documentos, procesos y activos lleven validez verificable on-chain.
Diseñada para usuarios, empresas, instituciones y profesionales (abogados, contadores,
ingenieros, escribanos) que aportan dictámenes humanos sobre cada caso.

---

## ✨ Características

- 🤖 **Análisis IA preliminar** de documentos cargados (riesgo + resumen)
- 👨‍⚖️ **Verificadores humanos** con especialidades (legal, contable, técnica, sanitaria)
- 📊 **Motor de scoring dinámico** (0–100) con historial completo
- 🔗 **Tokenización NFT** en ETTIOS Blockchain (ERC-721, Chain ID 2237)
- 📜 **4 tipos de certificación**: CTE · CTPI · CEN · CTK
- ⚖️ **Marco legal SEPRELAD** con log inmutable de consentimientos
- 🔍 **Verificación pública** por hash SHA-256, token ID o QR
- 🌍 **Pagos para España** (CaixaBank · Cyberpac · Redsys · Bizum)

---

## 🏗 Arquitectura

```
mtp-react/
├── client/            React 18 + Vite 5 + React Router 6
├── server/            Backend MySQL  (Express + MySQL2 + ethers.js)
└── server-mongo/      Backend MongoDB (Express + Mongoose + ethers.js)
```

**Elegí un backend** según tu stack:

| | `server/` (MySQL) | `server-mongo/` (MongoDB) |
|---|-------------------|---------------------------|
| Driver | mysql2 | mongoose |
| Schema | SQL declarativo (7 tablas) | Mongoose models (7 colecciones) |
| FK / Refs | claves foráneas | `ObjectId` + `populate()` |
| Mejor para | WAMP, PHP devs, queries complejas | cloud-first, esquemas flexibles |

El frontend funciona con cualquiera de los dos — el contrato HTTP es idéntico.

### Las 7 Capas del Framework MTP

| Capa | Implementación |
|------|----------------|
| **1** KYC dinámico | tabla/colección `legal_consents` + auditoría SEPRELAD |
| **2** Motor de IA | `src/ai.js` (heurístico, reemplazable por Claude/GPT) |
| **3** Validación humana | rol *verificador* + dictámenes con scoring |
| **4** Trazabilidad | `activity_log` + SHA-256 de cada archivo |
| **5** Scoring | `users.reputation` (0–100) + `scoring_history` |
| **6** Marketplace | `/marketplace` público, filtrable por sector |
| **7** Tokenización NFT | contrato Solidity 0.8.20 en ETTIOS |

---

## 🚀 Quickstart

```bash
git clone https://github.com/TU_USUARIO/mtp-platform.git
cd mtp-platform
```

### Backend (elegí uno)

**MySQL:**
```bash
cd server
npm install
cp .env.example .env       # editá DB_PASSWORD y demás
npm run init-db            # crea DB + 7 tablas + seed
npm run dev                # http://localhost:4000
```

**MongoDB:**
```bash
cd server-mongo
npm install
cp .env.example .env       # editá MONGO_URI
npm run init-db            # crea índices + seed
npm run dev                # http://localhost:4000
```

### Frontend

```bash
cd client
npm install
npm run dev                # http://localhost:5173
```

---

## 🧪 Cuentas demo

Después del `init-db`, todos los logins usan password **`mtp1234`**:

| Email | Rol | Membresía |
|-------|-----|-----------|
| `admin@mtp.test` | admin | premium |
| `empresa@mtp.test` | usuario | profesional |
| `usuario@mtp.test` | usuario | básica |
| `abogada@mtp.test` | verificador | premium |
| `contador@mtp.test` | verificador | profesional |

Tras login, cada rol entra a su panel:
- `usuario` → `/u` (carga documentos, ve su reputación)
- `verificador` → `/verificador` (cola de validación)
- `admin` → `/admin` (usuarios, scoring, NFTs)

---

## 📡 API principales

| Método | Endpoint | Auth | Descripción |
|--------|----------|------|-------------|
| `GET` | `/api/health` | público | Estado DB + blockchain |
| `POST` | `/api/auth/register` | público | Con 3 consentimientos obligatorios |
| `POST` | `/api/auth/login` | público | Devuelve `{user, token}` |
| `GET` | `/api/marketplace/professionals` | público | Listado filtrable |
| `GET` | `/api/verify/:identifier` | público | Hash SHA-256 / token ID / doc ID |
| `POST` | `/api/documents` | usuario | Multipart con archivo |
| `POST` | `/api/validations` | verificador | Emitir dictamen |
| `POST` | `/api/nft/mint/:docId` | propietario | Mintear NFT en ETTIOS |
| `POST` | `/api/kyc` | usuario | Enviar datos de identidad |

Lista completa: ver [API.md](docs/API.md).

---

## ⛓ Smart Contract

`MTPValidationNFT.sol` — ERC-721 autocontenido en Solidity 0.8.20.

**Deploy rápido con Remix:**
1. Abrí https://remix.ethereum.org
2. Pegá el contenido de `server/contracts/MTPValidationNFT.sol`
3. Compilá con Solidity `0.8.20`
4. Configurá MetaMask con la red ETTIOS (Chain ID `2237`)
5. Deploy → copiá la dirección a `.env` como `ETTIOS_CONTRACT_ADDRESS`

---

## 🤝 Atribución

Este proyecto se construye sobre el whitepaper de:

- **Autor intelectual**: Lic. Pablo Rutigliano
- **Titular patrimonial**: Aston Mining S.L.
- **Desarrollo tecnológico**: ETTIOS

---

## 📄 Licencia

[MIT](LICENSE) — uso libre para proyectos personales y comerciales.

---

## 🛠 Stack

**Backend** Node 22 · Express 4.21 · MySQL2 3.11 / Mongoose 8.8 · ethers.js 6.13 · bcryptjs · multer · jsonwebtoken
**Frontend** React 18.3 · Vite 5.4 · React Router 6.28
**Blockchain** Solidity 0.8.20 · ERC-721 · ETTIOS L1 (Chain ID 2237)
**DB** MySQL 8 / MariaDB 10.4+ — **o** — MongoDB 7+
