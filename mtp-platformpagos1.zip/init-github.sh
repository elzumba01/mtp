#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────
#  init-github.sh
#  Inicializa el repositorio Git local y lo conecta a GitHub.
#  Uso: ./init-github.sh <usuario-github> [nombre-del-repo]
# ──────────────────────────────────────────────────────────────────

set -e

USER="${1:-}"
REPO="${2:-mtp-platform}"

if [ -z "$USER" ]; then
  echo "✗ Pasame tu usuario de GitHub:"
  echo "  ./init-github.sh TU_USUARIO [nombre-repo]"
  echo ""
  echo "  Ejemplo: ./init-github.sh facundo mtp-platform"
  exit 1
fi

# Verificaciones previas
command -v git >/dev/null 2>&1 || { echo "✗ Git no está instalado"; exit 1; }

if [ -d .git ]; then
  echo "⚠ Ya existe un repo Git en este directorio."
  read -p "¿Querés reinicializarlo? Esto BORRA el historial. [y/N] " confirm
  [ "$confirm" = "y" ] || exit 0
  rm -rf .git
fi

echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Inicializando repo MTP Platform en GitHub"
echo "═══════════════════════════════════════════════════════"
echo "  Usuario: $USER"
echo "  Repo:    $REPO"
echo ""

# 1) Inicializar
git init -b main
echo "✓ Repo inicializado (rama: main)"

# 2) Configurar identidad si falta
if [ -z "$(git config user.email)" ]; then
  read -p "Email para commits: " email
  read -p "Nombre para commits: " name
  git config user.email "$email"
  git config user.name "$name"
fi

# 3) Verificar que no haya secretos antes de commitear
echo ""
echo "▶ Verificando que no haya secretos…"
if find . -name ".env" -not -path '*/node_modules/*' 2>/dev/null | grep -q '.'; then
  echo "✗ Encontré archivos .env. Eliminalos o agregalos a .gitignore antes de continuar."
  exit 1
fi
if grep -rE 'JWT_SECRET=[a-zA-Z0-9]{8,}' --include='*.js' --include='*.json' . 2>/dev/null | grep -v 'cambiar_este\|test_secret\|ci_secret\|\.env\.example' | grep -q '.'; then
  echo "⚠ Posibles secretos hardcodeados detectados (revisar manualmente)"
fi
echo "✓ Sin secretos detectados"

# 4) Primer commit
git add .
git commit -m "feat: initial release of MTP Platform

- Frontend React 18 + Vite 5 con landing, marketplace y panels por rol
- Backend MySQL (Express + MySQL2 + ethers.js)
- Backend MongoDB (Express + Mongoose + ethers.js) [alternativo]
- Smart contract ERC-721 (Solidity 0.8.20) para ETTIOS Blockchain
- Marco legal SEPRELAD: T&C, Privacidad, KYC con auditoría inmutable
- Verificador público por hash SHA-256 / token ID
- Roadmap 6 fases · 7 capas del framework MTP

Autor intelectual: Lic. Pablo Rutigliano
Titular patrimonial: Aston Mining S.L.
Desarrollo: ETTIOS"
echo "✓ Primer commit creado"

# 5) Conectar con GitHub
git remote add origin "https://github.com/$USER/$REPO.git"
echo ""
echo "═══════════════════════════════════════════════════════"
echo "  Próximos pasos"
echo "═══════════════════════════════════════════════════════"
echo ""
echo "1) Creá el repo en GitHub (vacío, sin README ni .gitignore):"
echo "     https://github.com/new?name=$REPO"
echo ""
echo "2) Pusheá:"
echo "     git push -u origin main"
echo ""
echo "3) Configurá los Secrets si vas a usar el CI (Settings → Secrets):"
echo "     - (opcional) Si conectás MongoDB Atlas: MONGO_URI_CI"
echo "     - (opcional) Si querés deployar: VERCEL_TOKEN, etc."
echo ""
echo "✓ Todo listo!"
