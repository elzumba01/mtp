import { useEffect } from 'react';
import { Navigate } from 'react-router-dom';

/**
 * Marketplace ahora vive embebido en el landing principal.
 * Esta página se mantiene como atajo: redirige a /#marketplace.
 */
export default function Marketplace() {
  useEffect(() => {
    // Pequeño hint visual antes del redirect
    document.title = 'Redirigiendo al marketplace…';
  }, []);
  return <Navigate to="/#marketplace" replace />;
}
