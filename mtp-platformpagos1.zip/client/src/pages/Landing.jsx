import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';
import { MEMBERSHIPS } from '../lib.js';

// ─── Contenido estático del landing ─────────────────────────────────
const CERTS = [
  { code: 'CTE',  name: 'Trazabilidad Económica',
    desc: 'Proyectos, empresas, inversiones, compliance y estructuras financieras.',
    bullets: ['Bancos, inversores y fondos.','Startups y proyectos productivos.','Validación económica, jurídica y documental.'] },
  { code: 'CTPI', name: 'Procesos Inteligentes',
    desc: 'Procesos judiciales, sanitarios, productivos y gubernamentales.',
    bullets: ['Justicia, municipios, gobiernos y hospitales.','Empresas, universidades y ciudadanos.','Línea de tiempo, evidencia, riesgos y dictámenes.'] },
  { code: 'CEN',  name: 'Escritural Notarial',
    desc: 'Escribano digital con fe pública blockchain.',
    bullets: ['Contratos y poderes con validez notarial.','Escrituras públicas y privadas.','Protocolización on-chain.'] },
  { code: 'CTK',  name: 'Tokenización',
    desc: 'Activos reales tokenizados: inmuebles, ganado, vehículos eléctricos, clubes deportivos.',
    bullets: ['Cuotapartes en NFT transferibles.','Liquidez secundaria.','Custodio regulado.'] },
];

const SIMPLE_STEPS = [
  { n: 1, title: 'Inicio',            desc: 'Elegís: soy usuario, empresa, institución o verificador.' },
  { n: 2, title: 'Carga',             desc: 'Subís documentos y la plataforma muestra el progreso.' },
  { n: 3, title: 'Análisis IA',       desc: 'La IA resume, clasifica y detecta riesgos.' },
  { n: 4, title: 'Validación humana', desc: 'Verificadores idóneos revisan y dejan evidencia.' },
  { n: 5, title: 'Certificación',     desc: 'Recibís informe, score, QR y trazabilidad completa.' },
];

const ROADMAP = [
  { n: '01', title: 'Desarrollo Fundacional',           desc: 'Infraestructura base + 7 capas operativas + smart contracts ERC-721 en ETTIOS.', tag: 'Activo',  state: 'active' },
  { n: '02', title: 'Escalabilidad Multisectorial',     desc: 'Onboarding masivo de profesionales + sectores agro/inmobiliario/deporte.',        tag: 'Próximo', state: 'next' },
  { n: '03', title: 'Automatización IA',                desc: 'LLM real para pre-validación automática y triage inteligente.',                   tag: 'Futuro',  state: 'future' },
  { n: '04', title: 'Interoperabilidad Global',         desc: 'Bridges a Ethereum, Polygon, BSC. Estándar MiCA y reconocimiento legal cruzado.', tag: 'Futuro',  state: 'future' },
  { n: '05', title: 'Blockchain Readiness',             desc: 'Tokens ERC-1155 para fracción de activos, marketplace secundario.',               tag: 'Futuro',  state: 'future' },
  { n: '06', title: 'Infraestructura Económica Global', desc: 'MTP adoptado por gobiernos, municipios y bancos centrales.',                       tag: 'Futuro',  state: 'future' },
];

const FAQS = [
  { q: '¿Qué es la fe pública blockchain?',
    a: 'Es la rúbrica notarial trasladada a blockchain. El escribano digital firma criptográficamente el documento; el resultado se ancla on-chain con validez legal equivalente a la escritura tradicional bajo el marco EMPE/BCP de Paraguay.' },
  { q: '¿Cómo se calcula el scoring?',
    a: 'La reputación (0-100) combina KYC, calidad y cantidad de validaciones recibidas, historial profesional y antigüedad. Cada dictamen aprobado suma 8 puntos; cada uno rechazado resta 10.' },
  { q: '¿Qué red blockchain usan?',
    a: 'ETTIOS Blockchain — Layer 1 EVM-compatible con Chain ID 2237. Smart contracts auditados y explorer público en scan.ettiosblockchain.io.' },
  { q: '¿Quién puede ser verificador?',
    a: 'Profesionales con título habilitante: abogados, jueces, ex fiscales, contadores, médicos, ingenieros, técnicos, empresarios, auditores y especialistas.' },
  { q: '¿Los NFTs se pueden transferir?',
    a: 'Los CTE/CTPI/CEN son Soulbound — no transferibles, atados a la identidad. Los CTK (Tokenización) sí son transferibles porque representan activos reales.' },
];

// ─── Marketplace embebido ───────────────────────────────────────────
function MarketplaceSection() {
  const [sectors, setSectors]           = useState([]);
  const [sectorFilter, setSectorFilter] = useState(null);
  const [membFilter, setMembFilter]     = useState(null);
  const [pros, setPros]                 = useState([]);
  const [loading, setLoading]           = useState(true);

  useEffect(() => {
    api.get('/marketplace/sectors').then(setSectors).catch(() => setSectors([]));
  }, []);

  useEffect(() => {
    setLoading(true);
    const qs = new URLSearchParams();
    if (sectorFilter) qs.set('sector', sectorFilter);
    if (membFilter)   qs.set('membership', membFilter);
    api.get(`/marketplace/professionals${qs.toString() ? '?' + qs : ''}`)
      .then(setPros).catch(() => setPros([]))
      .finally(() => setLoading(false));
  }, [sectorFilter, membFilter]);

  return (
    <section className="lp-section lp-section-dark" id="marketplace">
      <div className="lp-section-head">
        <span className="lp-eyebrow">MARKETPLACE VIVO</span>
        <h2>Conectate con profesionales verificados ahora mismo.</h2>
        <p>Cada profesional pasó KYC y construyó su reputación con dictámenes reales. Filtrá por sector y membresía para encontrar al indicado.</p>
      </div>

      <div className="market-toolbar">
        <div className="filters">
          <button className={`filter-chip ${!sectorFilter ? 'active' : ''}`}
                  onClick={() => setSectorFilter(null)}>Todos los sectores</button>
          {sectors.map(s => (
            <button key={s} className={`filter-chip ${sectorFilter === s ? 'active' : ''}`}
                    onClick={() => setSectorFilter(s)}>{s}</button>
          ))}
        </div>
        <div className="filters">
          <button className={`filter-chip ${!membFilter ? 'active' : ''}`}
                  onClick={() => setMembFilter(null)}>Todas</button>
          {Object.entries(MEMBERSHIPS).map(([k, v]) => (
            <button key={k} className={`filter-chip ${membFilter === k ? 'active' : ''}`}
                    onClick={() => setMembFilter(k)}>{v.label}</button>
          ))}
        </div>
      </div>

      {loading
        ? <div className="empty-box">Cargando profesionales…</div>
        : pros.length === 0
          ? <div className="empty-box">
              <p>No hay profesionales con esos filtros.</p>
              <button className="btn btn-ghost btn-sm mt" onClick={() => { setSectorFilter(null); setMembFilter(null); }}>Limpiar filtros</button>
            </div>
          : <div className="grid grid-3">
              {pros.map(p => {
                const initials = (p.full_name || '?').split(' ').filter(Boolean).slice(0,2).map(s => s[0]).join('');
                const isPremium = p.membership === 'premium';
                return (
                  <div key={p.id} className={`card pro-card ${isPremium ? 'pro-card-premium' : ''}`}>
                    {isPremium && <span className="pro-ribbon">★ PREMIUM</span>}
                    <div className="pro-top">
                      <div className="pro-ava">{initials.toUpperCase()}</div>
                      <div>
                        <div className="pro-name">{p.full_name}</div>
                        <div className="pro-meta">{p.company_name || p.specialty || p.entity_type}</div>
                      </div>
                    </div>
                    <div className="pro-tags">
                      {p.sector && <span className="badge badge-info">{p.sector}</span>}
                      <span className={`badge mem-${p.membership || 'basic'}`}>{MEMBERSHIPS[p.membership]?.label || p.membership}</span>
                      {p.role === 'verificador' && <span className="badge badge-good">verificador</span>}
                    </div>
                    <div className="pro-foot">
                      <div>
                        <strong style={{ color: 'var(--cyan-600)', fontSize: '1.1rem', fontFamily: 'var(--font-display)' }}>{Math.round(Number(p.reputation))}</strong>
                        <span className="dim" style={{ fontSize: '.75rem' }}> /100</span>
                      </div>
                      <Link to={`/register`} className="btn btn-ghost btn-sm">Contactar</Link>
                    </div>
                  </div>
                );
              })}
            </div>}
    </section>
  );
}

// ─── Página principal ──────────────────────────────────────────────
export default function Landing() {
  const { user, roleHome, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [stats, setStats] = useState(null);
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll);
    api.get('/marketplace/stats').then(setStats).catch(() => {});
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="lp">
      {/* Navbar */}
      <nav className={`lp-nav ${scrolled ? 'is-scrolled' : ''}`}>
        <Link to="/" className="lp-brand">
          <div className="brand-mark">M<span>T</span>P</div>
          <div><strong>MTP Platform</strong><small>Economía Verificable</small></div>
        </Link>
        <div className="lp-nav-links">
          <a href="#simple">Cómo funciona</a>
          <a href="#marketplace">Marketplace</a>
          <a href="#certificaciones">Certificaciones</a>
          <a href="#roadmap">Roadmap</a>
          <a href="#pagos">Pagos</a>
          <Link to="/verify">Verificar</Link>
        </div>
        <div className="row" style={{ gap: 8 }}>
          {user
            ? <>
                <Link className="btn btn-ghost btn-sm" to={roleHome()}>Mi panel</Link>
                <button className="btn btn-primary btn-sm" onClick={logout}>Salir</button>
              </>
            : <>
                <Link className="btn btn-ghost btn-sm" to="/login">Ingresar</Link>
                <Link className="btn btn-primary btn-sm" to="/register">Comenzar</Link>
              </>}
        </div>
      </nav>

      {/* HERO */}
      <section className="lp-hero">
        <div className="lp-hero-inner">
          <div>
            <span className="lp-tag"><span className="lp-pulse"></span> IA + Verificadores + Usuarios + Trazabilidad</span>
            <h1><em>MTP Platform</em><br/>la red global de confianza verificable.</h1>
            <p>Una plataforma donde cada usuario carga información, sigue la trazabilidad, recibe validación profesional y obtiene evidencia verificable. Diseñada para personas, empresas, instituciones y verificadores.</p>
            <div className="row" style={{ gap: 13, marginTop: 30 }}>
              <Link to="/register" className="btn btn-primary">Quiero evaluar algo</Link>
              <Link to="/register?role=verificador" className="btn btn-green">Quiero ser verificador</Link>
              <a href="#marketplace" className="btn btn-gold">Explorar marketplace ↓</a>
            </div>
            {stats && (
              <div className="lp-hero-stats">
                <div><strong>{stats.professionals}</strong><span>profesionales</span></div>
                <div><strong>{Math.round(stats.avg_reputation)}</strong><span>reputación media</span></div>
                <div><strong>{stats.sectors}</strong><span>sectores</span></div>
                <div><strong>{stats.nfts_minted}</strong><span>NFTs en ETTIOS</span></div>
              </div>
            )}
          </div>
          <div className="lp-hero-card">
            <div className="row between" style={{ marginBottom: 18 }}>
              <div>
                <strong style={{ color: 'var(--ink)', fontSize: 18 }}>Centro de Control MTP</strong><br/>
                <small style={{ color: 'var(--ink-soft)' }}>Economía verificable en tiempo real</small>
              </div>
              <span className="lp-tag" style={{ margin: 0 }}>ECOSISTEMA ACTIVO</span>
            </div>
            <div className="grid grid-2" style={{ gap: 13 }}>
              <div className="card" style={{ padding: 17 }}>
                <div style={{ fontSize: 11, letterSpacing: '.13em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: 10 }}>Score de confianza</div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 52, lineHeight: 1, letterSpacing: '-.04em', background: 'linear-gradient(135deg,var(--green-500),var(--cyan-500))', WebkitBackgroundClip: 'text', color: 'transparent' }}>94</div>
                <div className="scorebar" style={{ marginTop: 12 }}><span style={{ width: '94%' }} /></div>
                <small className="dim">Evidencia y validaciones consolidadas</small>
              </div>
              <div className="card" style={{ padding: 17 }}>
                <div style={{ fontSize: 11, letterSpacing: '.13em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: 10 }}>Participación humana</div>
                <h3 style={{ fontSize: 38, color: 'var(--green-500)', margin: 0, fontWeight: 900, letterSpacing: '-.02em' }}>12</h3>
                <div className="scorebar" style={{ marginTop: 12 }}><span style={{ width: '78%' }} /></div>
                <small className="dim">Verificadores asignados por especialidad</small>
              </div>
            </div>
            <div className="card" style={{ padding: 17, marginTop: 13 }}>
              <div style={{ fontSize: 11, letterSpacing: '.13em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: 10 }}>Ruta de trazabilidad</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 8 }}>
                {['1. Cargo','2. Ordena IA','3. Valida humano','4. Se traza','5. Certifica'].map(t => (
                  <div key={t} style={{ padding: '10px 7px', borderRadius: 12, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 12, background: 'rgba(255,255,255,.6)', border: '1px solid var(--line)', fontWeight: 600 }}>{t}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRAZABILIDAD SIMPLE */}
      <section className="lp-section" id="simple">
        <div className="lp-section-head">
          <span className="lp-eyebrow">CÓMO FUNCIONA</span>
          <h2>Trazabilidad simple: siempre sabés dónde estás.</h2>
          <p>Ningún usuario ni verificador debe perderse dentro de la plataforma.</p>
        </div>
        <div className="simple-strip">
          {SIMPLE_STEPS.map(s => (
            <div key={s.n} className="simple-item">
              <b>{s.n}. {s.title}</b>
              <span>{s.desc}</span>
            </div>
          ))}
        </div>
      </section>

      {/* MARKETPLACE EMBEBIDO (datos reales del backend) */}
      <MarketplaceSection />

      {/* CERTIFICACIONES — 4 tipos */}
      <section className="lp-section" id="certificaciones">
        <div className="lp-section-head">
          <span className="lp-eyebrow">CERTIFICACIONES</span>
          <h2>Cuatro estándares de certificación on-chain.</h2>
          <p>Cada certificado se emite como NFT en ETTIOS con metadatos públicos verificables.</p>
        </div>
        <div className="grid grid-2">
          {CERTS.map(c => (
            <div key={c.code} className="card">
              <div className="lp-cert-head">
                <div className="lp-cert-icon">{c.code}</div>
                <div>
                  <div className="lp-cert-code">{c.code}</div>
                  <div className="lp-cert-name">{c.name}</div>
                </div>
              </div>
              <p className="muted" style={{ marginBottom: 12 }}>{c.desc}</p>
              <ul className="lp-list" style={{ marginTop: 0 }}>
                {c.bullets.map(b => <li key={b}>{b}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* ROADMAP — 6 FASES */}
      <section className="lp-section lp-section-dark" id="roadmap">
        <div className="lp-section-head">
          <span className="lp-eyebrow">ROADMAP · 6 FASES</span>
          <h2>De Desarrollo Fundacional a Infraestructura Económica Global.</h2>
        </div>
        <div className="roadmap">
          {ROADMAP.map(p => (
            <div key={p.n} className={`roadmap-phase roadmap-${p.state}`}>
              <div className="roadmap-num">{p.n}</div>
              <div className="roadmap-body">
                <div className="row between" style={{ alignItems: 'flex-start' }}>
                  <h3>{p.title}</h3>
                  <span className={`badge ${p.state === 'active' ? 'badge-good' : p.state === 'next' ? 'badge-warn' : 'badge-neutral'}`}>{p.tag}</span>
                </div>
                <p className="muted">{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PAGOS — ESPAÑA */}
      <section className="lp-section" id="pagos">
        <div className="lp-section-head">
          <span className="lp-eyebrow">PAGOS</span>
          <h2>Pagos listos para operar en España.</h2>
          <p>La plataforma incluye CaixaBank, Cyberpac, Redsys y Bizum para certificaciones, suscripciones, membresías y honorarios.</p>
        </div>
        <div className="payments">
          <div className="card">
            <h3>CaixaBank · Cyberpac · Redsys</h3>
            <p className="muted" style={{ marginBottom: 14 }}>TPV virtual compatible con Redsys, firma SHA-256, entornos test y producción, operaciones autorizadas/denegadas y notificaciones HTTP.</p>
            <span className="logo-pill">CaixaBank</span>
            <span className="logo-pill">Cyberpac</span>
            <span className="logo-pill">Redsys</span>
            <div className="mt"><Link to="/checkout" className="btn btn-primary btn-sm">Probar pago con tarjeta →</Link></div>
          </div>
          <div className="card">
            <h3>Bizum</h3>
            <p className="muted" style={{ marginBottom: 14 }}>Botón independiente de pago Bizum para que el usuario pague con número de teléfono y clave Bizum recibida por SMS.</p>
            <span className="logo-pill">Bizum</span>
            <span className="logo-pill">Mobile Pay</span>
            <span className="logo-pill">SMS Key</span>
            <div className="mt"><Link to="/checkout?plan=profesional" className="btn btn-primary btn-sm">Probar pago con Bizum →</Link></div>
          </div>
        </div>
      </section>

      {/* PROPIEDAD INTELECTUAL */}
      <section className="lp-section">
        <div className="ip-block">
          <h2>Propiedad intelectual, titularidad y desarrollo.</h2>
          <p className="muted" style={{ marginTop: 8 }}>Figura con claridad institucional en la web y en el footer.</p>
          <div className="ip-grid">
            <div className="ip-item">
              <span>Autor intelectual y creador conceptual</span>
              <strong>Lic. Pablo Rutigliano</strong>
            </div>
            <div className="ip-item">
              <span>Titular patrimonial</span>
              <strong>Aston Mining S.L.</strong>
            </div>
            <div className="ip-item">
              <span>Desarrollo tecnológico de la web</span>
              <strong>ETTIOS</strong>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="lp-section lp-section-dark">
        <div className="lp-section-head">
          <span className="lp-eyebrow">PREGUNTAS FRECUENTES</span>
          <h2>Lo que más nos preguntan.</h2>
        </div>
        <div style={{ maxWidth: 760, margin: '0 auto' }}>
          {FAQS.map((f, i) => (
            <div key={i} className={`lp-faq ${openFaq === i ? 'is-open' : ''}`}
                 onClick={() => setOpenFaq(openFaq === i ? -1 : i)}>
              <div className="lp-faq-q">
                <span>{f.q}</span>
                <span className="lp-faq-toggle">{openFaq === i ? '−' : '+'}</span>
              </div>
              {openFaq === i && <p className="lp-faq-a muted">{f.a}</p>}
            </div>
          ))}
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="lp-cta" id="empezar">
        <div className="lp-cta-panel">
          <span className="lp-tag"><span className="lp-pulse"></span> La confianza se vuelve visible</span>
          <h2 style={{ marginTop: 18 }}>Una plataforma clara para todos. Una infraestructura poderosa para el mundo.</h2>
          <p className="muted" style={{ fontSize: 19, maxWidth: 780, margin: '14px auto 30px' }}>MTP Platform une usuarios, verificadores, instituciones e inteligencia artificial para construir la economía verificable del futuro.</p>
          <div className="row" style={{ justifyContent: 'center', gap: 12, flexWrap: 'wrap' }}>
            <Link to="/register" className="btn btn-primary">Crear cuenta</Link>
            <Link to="/register?role=verificador" className="btn btn-green">Ser verificador</Link>
            <a href="#marketplace" className="btn btn-gold">Ver marketplace</a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="lp-foot">
        <div className="row between" style={{ flexWrap: 'wrap', gap: 20 }}>
          <div>
            <strong style={{ color: 'var(--ink)', fontFamily: 'var(--font-display)', fontSize: '1.05rem' }}>MTP Platform</strong>
            <p className="dim mt">Infraestructura Global de Economía Verificable.</p>
            <p className="dim">© 2026 Lic. Pablo Rutigliano. Todos los derechos reservados.</p>
          </div>
          <div className="dim" style={{ textAlign: 'right' }}>
            <div>Desarrollo tecnológico: <strong style={{ color: 'var(--cyan-600)' }}>ETTIOS</strong></div>
            <div>Titular patrimonial: <strong style={{ color: 'var(--ink)' }}>Aston Mining S.L.</strong></div>
            <code style={{ fontSize: 11, color: 'var(--cyan-600)' }}>rpc.ettiosblockchain.io</code>
          </div>
        </div>
      </footer>
    </div>
  );
}
