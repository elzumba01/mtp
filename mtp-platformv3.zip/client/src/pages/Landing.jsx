import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';

const CERTS = [
  { code: 'CTE',  name: 'Certificado de Trazabilidad Económica',
    desc: 'Evalúa proyectos, empresas, activos, inversiones, documentación económica, estructura financiera, reputación, riesgo y viabilidad.',
    bullets: ['Bancos, inversores y fondos.','Startups, empresas y proyectos productivos.','Validación económica, financiera, jurídica y documental.'] },
  { code: 'CTPI', name: 'Certificado de Trazabilidad de Procesos Inteligentes',
    desc: 'Evalúa procesos judiciales, administrativos, hospitalarios, empresariales, productivos, laborales y gubernamentales.',
    bullets: ['Justicia, municipios, gobiernos y hospitales.','Empresas, universidades y ciudadanos.','Línea de tiempo, evidencia, riesgos y dictámenes.'] },
];

const SIMPLE_STEPS = [
  { n: 1, title: 'Inicio',            desc: 'Elegís: soy usuario, empresa, institución o verificador.' },
  { n: 2, title: 'Carga',             desc: 'Subís documentos y la plataforma muestra el porcentaje completado.' },
  { n: 3, title: 'Análisis IA',       desc: 'La IA resume, clasifica, detecta riesgos y marca faltantes.' },
  { n: 4, title: 'Validación humana', desc: 'Verificadores idóneos revisan, opinan y dejan evidencia.' },
  { n: 5, title: 'Certificación',     desc: 'Recibís informe, score, QR y línea de trazabilidad completa.' },
];

const USER_STEPS = [
  { n: 1, title: 'Crear cuenta simple',     desc: 'Persona, empresa, gobierno, hospital, justicia o inversor.' },
  { n: 2, title: 'Elegir qué necesito',     desc: 'Certificado económico, certificado de proceso o análisis preliminar.' },
  { n: 3, title: 'Cargar documentación',    desc: 'PDF, Word, imágenes, expedientes, balances, contratos o informes.' },
  { n: 4, title: 'Recibir trazabilidad',    desc: 'Dashboard claro, informe descargable, score, QR y certificado.' },
];

const VERIFIER_STEPS = [
  { n: 1, title: 'Crear perfil profesional',  desc: 'CV, LinkedIn, matrícula, certificaciones, títulos y experiencia.' },
  { n: 2, title: 'Indicar especialidades',    desc: 'Jurídica, económica, salud, logística, tecnología, industria y más.' },
  { n: 3, title: 'Participar en validaciones',desc: 'Dictámenes, observaciones, votos técnicos y revisión de evidencia.' },
  { n: 4, title: 'Construir reputación',      desc: 'Score profesional, historial, honorarios y reconocimiento del ecosistema.' },
];

const FLOW = [
  { n: '01', title: 'Usuario presenta',  desc: 'Cuenta el caso en lenguaje simple.' },
  { n: '02', title: 'Documentos',         desc: 'Sube archivos y antecedentes.' },
  { n: '03', title: 'IA procesa',         desc: 'Resume, clasifica y detecta inconsistencias.' },
  { n: '04', title: 'Matching',           desc: 'Busca verificadores idóneos.' },
  { n: '05', title: 'Verificadores',      desc: 'Aportan experiencia sectorial.' },
  { n: '06', title: 'Consenso',           desc: 'Se consolida criterio profesional.' },
  { n: '07', title: 'Certificado',        desc: 'Score, QR, informe y trazabilidad.' },
];

const LAYERS = [
  { n: 'CAPA 1', title: 'Identidad',     desc: 'Registro, KYC, KYB y perfiles.' },
  { n: 'CAPA 2', title: 'IA',            desc: 'NLP, OCR, resumen y riesgo.' },
  { n: 'CAPA 3', title: 'Humana',        desc: 'Verificadores y dictámenes.' },
  { n: 'CAPA 4', title: 'Trazabilidad',  desc: 'Historial y evidencia.' },
  { n: 'CAPA 5', title: 'Scoring',       desc: 'Riesgo y reputación.' },
  { n: 'CAPA 6', title: 'Marketplace',   desc: 'Conexión económica.' },
  { n: 'CAPA 7', title: 'Futuro',        desc: 'APIs y blockchain ready.' },
];

const ROADMAP = [
  { n: '01', title: 'Desarrollo Fundacional',           desc: 'Infraestructura base + 7 capas operativas + smart contracts ERC-721 en ETTIOS.',                              tag: 'Activo',   state: 'active' },
  { n: '02', title: 'Escalabilidad Multisectorial',     desc: 'Onboarding masivo de profesionales (legal, contable, técnico, escribanos) + sectores agro/inmobiliario/deporte.', tag: 'Próximo',  state: 'next' },
  { n: '03', title: 'Automatización IA',                desc: 'Reemplazo del motor IA heurístico por LLM real (Claude/GPT). Pre-validación automática y triage inteligente.',  tag: 'Futuro',   state: 'future' },
  { n: '04', title: 'Interoperabilidad Global',         desc: 'Bridges a Ethereum, Polygon, BSC. Adopción del estándar MiCA y reconocimiento legal cruzado PY/AR/UE.',         tag: 'Futuro',   state: 'future' },
  { n: '05', title: 'Blockchain Readiness',             desc: 'Tokens ERC-1155 para fracción de activos, marketplace secundario, integración con custodios regulados.',         tag: 'Futuro',   state: 'future' },
  { n: '06', title: 'Infraestructura Económica Global', desc: 'MTP como capa estándar de validación verificable adoptada por gobiernos, municipios y bancos centrales.',        tag: 'Futuro',   state: 'future' },
];

const FAQS = [
  { q: '¿Qué es la fe pública blockchain?',
    a: 'Es la rúbrica notarial trasladada a blockchain. El escribano digital firma criptográficamente el documento; el resultado se ancla on-chain con validez legal equivalente a la escritura tradicional bajo el marco EMPE/BCP de Paraguay.' },
  { q: '¿Cómo se calcula el scoring?',
    a: 'La reputación (0-100) combina KYC, calidad y cantidad de validaciones recibidas, historial profesional y antigüedad. Cada dictamen aprobado suma 8 puntos; cada uno rechazado resta 10.' },
  { q: '¿Qué red blockchain usan?',
    a: 'ETTIOS Blockchain — Layer 1 EVM-compatible con Chain ID 2237. Smart contracts auditados y explorer público en scan.ettiosblockchain.io.' },
  { q: '¿Quién puede ser verificador?',
    a: 'Profesionales con título habilitante: abogados, jueces, ex fiscales, contadores, médicos, ingenieros, técnicos, empresarios, auditores y especialistas.' },
  { q: '¿Los NFTs se pueden transferir?',
    a: 'Los CTE/CTPI/CEN son Soulbound — no transferibles, atados a la identidad. Los CTK (Tokenización) sí son transferibles porque representan activos reales.' },
];

export default function Landing() {
  const { user, roleHome, logout } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [stats, setStats] = useState(null);
  const [openFaq, setOpenFaq] = useState(0);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll);
    api.get('/marketplace/stats').then(setStats).catch(() => {});
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div className="lp">
      {/* Navbar */}
      <nav className={`lp-nav ${scrolled ? 'is-scrolled' : ''}`}>
        <Link to="/" className="lp-brand">
          <div className="brand-mark">M<span>T</span>P</div>
          <div><strong>MTP Platform</strong><small>Economía Verificable</small></div>
        </Link>
        <div className="lp-nav-links">
          <a href="#simple">Cómo funciona</a>
          <a href="#usuarios">Usuarios</a>
          <a href="#certificaciones">Certificaciones</a>
          <a href="#tecnologia">Tecnología</a>
          <a href="#pagos">Pagos</a>
          <Link to="/verify">Verificar</Link>
          <Link to="/marketplace">Marketplace</Link>
        </div>
        <div className="row" style={{ gap: 8 }}>
          {user
            ? <>
                <Link className="btn btn-ghost btn-sm" to={roleHome()}>Mi panel</Link>
                <button className="btn btn-primary btn-sm" onClick={logout}>Salir</button>
              </>
            : <>
                <Link className="btn btn-ghost btn-sm" to="/login">Ingresar</Link>
                <Link className="btn btn-primary btn-sm" to="/register">Comenzar</Link>
              </>}
        </div>
      </nav>

      {/* HERO */}
      <section className="lp-hero">
        <div className="lp-hero-inner">
          <div>
            <span className="lp-tag"><span className="lp-pulse"></span> IA + Verificadores + Usuarios + Trazabilidad</span>
            <h1><em>MTP Platform</em><br/>la red global de confianza verificable.</h1>
            <p>Una plataforma clara, humana y tecnológica donde cada usuario entiende el camino: cargar información, seguir la trazabilidad, recibir validación profesional y obtener evidencia verificable. Diseñada para personas, empresas, instituciones y verificadores.</p>
            <div className="row" style={{ gap: 13, marginTop: 30 }}>
              <Link to="/register" className="btn btn-primary">Quiero evaluar algo</Link>
              <Link to="/register?role=verificador" className="btn btn-green">Quiero ser verificador</Link>
              <Link to="/verify" className="btn btn-gold">Ver demo visual</Link>
            </div>
            <div className="decision-box">
              <div className="decision"><b>Para usuarios</b><span>Cargan proyectos, procesos, expedientes o documentación.</span></div>
              <div className="decision"><b>Para verificadores</b><span>Aportan experiencia, dictámenes y validación profesional.</span></div>
              <div className="decision"><b>Para instituciones</b><span>Construyen trazabilidad, scoring y certificación.</span></div>
            </div>
            {stats && (
              <div className="lp-hero-stats">
                <div><strong>{stats.professionals}</strong><span>profesionales</span></div>
                <div><strong>{Math.round(stats.avg_reputation)}</strong><span>reputación media</span></div>
                <div><strong>{stats.sectors}</strong><span>sectores</span></div>
                <div><strong>{stats.nfts_minted}</strong><span>NFTs en ETTIOS</span></div>
              </div>
            )}
          </div>
          <div className="lp-hero-card">
            <div className="row between" style={{ marginBottom: 18 }}>
              <div>
                <strong style={{ color: 'var(--ink)', fontSize: 18 }}>Centro de Control MTP</strong><br/>
                <small style={{ color: 'var(--ink-soft)' }}>Economía verificable en tiempo real</small>
              </div>
              <span className="lp-tag" style={{ margin: 0 }}>ECOSISTEMA ACTIVO</span>
            </div>
            <div className="grid grid-2" style={{ gap: 13 }}>
              <div className="card" style={{ padding: 17 }}>
                <div style={{ fontSize: 11, letterSpacing: '.13em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: 10 }}>Score de confianza</div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 52, lineHeight: 1, letterSpacing: '-.04em', background: 'linear-gradient(135deg,var(--green-500),var(--cyan-500))', WebkitBackgroundClip: 'text', color: 'transparent' }}>94</div>
                <div className="scorebar" style={{ marginTop: 12 }}><span style={{ width: '94%' }} /></div>
                <small className="dim">Evidencia y validaciones consolidadas</small>
              </div>
              <div className="card" style={{ padding: 17 }}>
                <div style={{ fontSize: 11, letterSpacing: '.13em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: 10 }}>Participación humana</div>
                <h3 style={{ fontSize: 38, color: 'var(--green-500)', margin: 0, fontWeight: 900, letterSpacing: '-.02em' }}>12</h3>
                <div className="scorebar" style={{ marginTop: 12 }}><span style={{ width: '78%' }} /></div>
                <small className="dim">Verificadores asignados por especialidad</small>
              </div>
            </div>
            <div className="card" style={{ padding: 17, marginTop: 13 }}>
              <div style={{ fontSize: 11, letterSpacing: '.13em', textTransform: 'uppercase', color: 'var(--ink-soft)', marginBottom: 10 }}>Ruta de trazabilidad</div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5,1fr)', gap: 8 }}>
                {['1. Cargo','2. Ordena IA','3. Valida humano','4. Se traza','5. Certifica'].map(t => (
                  <div key={t} style={{ padding: '10px 7px', borderRadius: 12, textAlign: 'center', color: 'var(--ink-soft)', fontSize: 12, background: 'rgba(255,255,255,.6)', border: '1px solid var(--line)', fontWeight: 600 }}>{t}</div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRAZABILIDAD SIMPLE — 5 PASOS */}
      <section className="lp-section lp-section-dark" id="simple">
        <div className="lp-section-head">
          <span className="lp-eyebrow">CÓMO FUNCIONA</span>
          <h2>Trazabilidad simple: siempre sabés dónde estás y qué falta.</h2>
          <p>La navegación debe estar guiada como un mapa. Ningún usuario ni verificador debe perderse dentro de la plataforma.</p>
        </div>
        <div className="simple-strip">
          {SIMPLE_STEPS.map(s => (
            <div key={s.n} className="simple-item">
              <b>{s.n}. {s.title}</b>
              <span>{s.desc}</span>
            </div>
          ))}
        </div>
      </section>

      {/* DOS PUERTAS DE ENTRADA */}
      <section className="lp-section" id="usuarios">
        <div className="lp-section-head">
          <span className="lp-eyebrow">PUERTAS DE ENTRADA</span>
          <h2>Dos puertas de entrada: usuarios y verificadores.</h2>
          <p>La web debe conectar emocional y funcionalmente con ambos. MTP crece cuando el usuario necesita validar y el verificador aporta experiencia.</p>
        </div>
        <div className="path">
          <div className="path-card">
            <span className="lp-tag"><span className="lp-pulse"></span> Portal de Usuarios</span>
            <h3>Quiero evaluar un proyecto, proceso o problema.</h3>
            <p>Para ciudadanos, empresas, hospitales, gobiernos, municipios, inversores, universidades y organizaciones.</p>
            <div className="steps">
              {USER_STEPS.map(s => (
                <div key={s.n} className="step">
                  <div className="num">{s.n}</div>
                  <div><strong>{s.title}</strong><span>{s.desc}</span></div>
                </div>
              ))}
            </div>
          </div>
          <div className="path-card verifier" id="verificadores">
            <span className="lp-tag"><span className="lp-pulse"></span> Portal de Verificadores</span>
            <h3>Quiero transformar mi experiencia en valor verificable.</h3>
            <p>Para abogados, jueces, ex fiscales, contadores, médicos, ingenieros, técnicos, empresarios, auditores y especialistas.</p>
            <div className="steps">
              {VERIFIER_STEPS.map(s => (
                <div key={s.n} className="step">
                  <div className="num">{s.n}</div>
                  <div><strong>{s.title}</strong><span>{s.desc}</span></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* FLUJO DE 7 PASOS */}
      <section className="lp-section lp-section-dark">
        <div className="lp-section-head">
          <span className="lp-eyebrow">VALIDACIÓN INTELIGENTE</span>
          <h2>La validación no debe ser automática. Debe ser inteligente y humana.</h2>
          <p>MTP no reemplaza especialistas. Los convierte en el núcleo de la plataforma.</p>
        </div>
        <div className="flowline">
          {FLOW.map(f => (
            <div key={f.n} className="flow-step">
              <b>{f.n}</b>
              <strong>{f.title}</strong>
              <span>{f.desc}</span>
            </div>
          ))}
        </div>
      </section>

      {/* CERTIFICACIONES */}
      <section className="lp-section" id="certificaciones">
        <div className="lp-section-head">
          <span className="lp-eyebrow">CERTIFICACIONES</span>
          <h2>Certificaciones claras, entendibles y con impacto institucional.</h2>
          <p>El usuario no debe confundirse. MTP ofrece dos grandes certificados iniciales.</p>
        </div>
        <div className="grid grid-2">
          {CERTS.map(c => (
            <div key={c.code} className="card">
              <div className="lp-cert-head">
                <div className="lp-cert-icon">{c.code}</div>
                <div>
                  <div className="lp-cert-code">{c.code}</div>
                  <div className="lp-cert-name">{c.name}</div>
                </div>
              </div>
              <p className="muted" style={{ marginBottom: 12 }}>{c.desc}</p>
              <ul className="lp-list" style={{ marginTop: 0 }}>
                {c.bullets.map(b => <li key={b}>{b}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* MARKETPLACE VERIFICABLE */}
      <section className="lp-section lp-section-dark">
        <div className="market-grid">
          <div>
            <div className="lp-section-head" style={{ textAlign: 'left', marginBottom: 28 }}>
              <span className="lp-eyebrow">MARKETPLACE</span>
              <h2>Marketplace verificable: la comunidad viva de MTP.</h2>
              <p style={{ margin: '14px 0 0' }}>No es un marketplace común. Es una red donde usuarios, verificadores, instituciones e inversores se conectan por confianza, evidencia y reputación.</p>
            </div>
            <div className="grid grid-2">
              <div className="card">
                <h3>Para usuarios</h3>
                <p className="muted">Encuentran profesionales, reciben certificaciones y acceden a oportunidades verificadas.</p>
              </div>
              <div className="card">
                <h3>Para verificadores</h3>
                <p className="muted">Reciben casos, honorarios, reputación y participación activa en validaciones reales.</p>
              </div>
            </div>
          </div>
          <div className="market-map">
            <div className="node center-node">MTP Platform</div>
            <div className="node n1">Usuarios</div>
            <div className="node n2">Verificadores</div>
            <div className="node n3">Gobiernos</div>
            <div className="node n4">Inversores</div>
            <div className="node n5">Hospitales</div>
            <div className="node n6">Empresas</div>
          </div>
        </div>
      </section>

      {/* ARQUITECTURA — 7 CAPAS */}
      <section className="lp-section" id="tecnologia">
        <div className="lp-section-head">
          <span className="lp-eyebrow">ARQUITECTURA</span>
          <h2>Arquitectura futurista, modular y escalable.</h2>
          <p>Preparada para cloud, IA, dashboards, certificados, pagos, APIs y crecimiento internacional.</p>
        </div>
        <div className="architecture">
          {LAYERS.map(l => (
            <div key={l.n} className="layer">
              <b>{l.n}</b>
              <h4>{l.title}</h4>
              <p>{l.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ROADMAP — 6 FASES */}
      <section className="lp-section lp-section-dark" id="roadmap">
        <div className="lp-section-head">
          <span className="lp-eyebrow">ROADMAP · 6 FASES</span>
          <h2>De Desarrollo Fundacional a Infraestructura Económica Global.</h2>
        </div>
        <div className="roadmap">
          {ROADMAP.map(p => (
            <div key={p.n} className={`roadmap-phase roadmap-${p.state}`}>
              <div className="roadmap-num">{p.n}</div>
              <div className="roadmap-body">
                <div className="row between" style={{ alignItems: 'flex-start' }}>
                  <h3>{p.title}</h3>
                  <span className={`badge ${p.state === 'active' ? 'badge-good' : p.state === 'next' ? 'badge-warn' : 'badge-neutral'}`}>{p.tag}</span>
                </div>
                <p className="muted">{p.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* PAGOS — ESPAÑA */}
      <section className="lp-section" id="pagos">
        <div className="lp-section-head">
          <span className="lp-eyebrow">PAGOS</span>
          <h2>Pagos listos para operar en España.</h2>
          <p>La plataforma incluye CaixaBank, Cyberpac, Redsys y Bizum para certificaciones, suscripciones, membresías y honorarios.</p>
        </div>
        <div className="payments">
          <div className="card">
            <h3>CaixaBank · Cyberpac · Redsys</h3>
            <p className="muted" style={{ marginBottom: 14 }}>TPV virtual compatible con Redsys, firma SHA-256, entornos test y producción, operaciones autorizadas/denegadas y notificaciones HTTP.</p>
            <span className="logo-pill">CaixaBank</span>
            <span className="logo-pill">Cyberpac</span>
            <span className="logo-pill">Redsys</span>
          </div>
          <div className="card">
            <h3>Bizum</h3>
            <p className="muted" style={{ marginBottom: 14 }}>Botón independiente de pago Bizum para que el usuario pague con número de teléfono y clave Bizum recibida por SMS.</p>
            <span className="logo-pill">Bizum</span>
            <span className="logo-pill">Mobile Pay</span>
            <span className="logo-pill">SMS Key</span>
          </div>
        </div>
      </section>

      {/* PROPIEDAD INTELECTUAL */}
      <section className="lp-section">
        <div className="ip-block">
          <h2>Propiedad intelectual, titularidad y desarrollo.</h2>
          <p className="muted" style={{ marginTop: 8 }}>Figura con claridad institucional en la web y en el footer.</p>
          <div className="ip-grid">
            <div className="ip-item">
              <span>Autor intelectual y creador conceptual</span>
              <strong>Lic. Pablo Rutigliano</strong>
            </div>
            <div className="ip-item">
              <span>Titular patrimonial</span>
              <strong>Aston Mining S.L.</strong>
            </div>
            <div className="ip-item">
              <span>Desarrollo tecnológico de la web</span>
              <strong>ETTIOS</strong>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="lp-section lp-section-dark">
        <div className="lp-section-head">
          <span className="lp-eyebrow">PREGUNTAS FRECUENTES</span>
          <h2>Lo que más nos preguntan.</h2>
        </div>
        <div style={{ maxWidth: 760, margin: '0 auto' }}>
          {FAQS.map((f, i) => (
            <div key={i} className={`lp-faq ${openFaq === i ? 'is-open' : ''}`}
                 onClick={() => setOpenFaq(openFaq === i ? -1 : i)}>
              <div className="lp-faq-q">
                <span>{f.q}</span>
                <span className="lp-faq-toggle">{openFaq === i ? '−' : '+'}</span>
              </div>
              {openFaq === i && <p className="lp-faq-a muted">{f.a}</p>}
            </div>
          ))}
        </div>
      </section>

      {/* CTA FINAL */}
      <section className="lp-cta" id="empezar">
        <div className="lp-cta-panel">
          <span className="lp-tag"><span className="lp-pulse"></span> La confianza se vuelve visible</span>
          <h2 style={{ marginTop: 18 }}>Una plataforma clara para todos. Una infraestructura poderosa para el mundo.</h2>
          <p className="muted" style={{ fontSize: 19, maxWidth: 780, margin: '14px auto 30px' }}>MTP Platform une usuarios, verificadores, instituciones e inteligencia artificial para construir la economía verificable del futuro.</p>
          <div className="row" style={{ justifyContent: 'center', gap: 12, flexWrap: 'wrap' }}>
            <Link to="/register" className="btn btn-primary">Crear cuenta</Link>
            <Link to="/register?role=verificador" className="btn btn-green">Ser verificador</Link>
            <Link to="/verify" className="btn btn-gold">Solicitar demo</Link>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="lp-foot">
        <div className="row between" style={{ flexWrap: 'wrap', gap: 20 }}>
          <div>
            <strong style={{ color: 'var(--ink)', fontFamily: 'var(--font-display)', fontSize: '1.05rem' }}>MTP Platform</strong>
            <p className="dim mt">Infraestructura Global de Economía Verificable.</p>
            <p className="dim">© 2026 Lic. Pablo Rutigliano. Todos los derechos reservados.</p>
          </div>
          <div className="dim" style={{ textAlign: 'right' }}>
            <div>Desarrollo tecnológico de la web: <strong style={{ color: 'var(--cyan-600)' }}>ETTIOS</strong></div>
            <div>Titular patrimonial: <strong style={{ color: 'var(--ink)' }}>Aston Mining S.L.</strong></div>
            <code style={{ fontSize: 11, color: 'var(--cyan-600)' }}>rpc.ettiosblockchain.io</code>
          </div>
        </div>
      </footer>
    </div>
  );
}
