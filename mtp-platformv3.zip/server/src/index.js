/**
 * MTP PLATFORM — Servidor Express.
 * API REST con autenticación JWT, integración con MySQL y minteo de NFTs en ETTIOS.
 */
import 'dotenv/config';
import express from 'express';
import cors from 'cors';

import { testConnection, getDbStatus, friendlySqlError } from './db.js';
import { ettiosHealth } from './blockchain.js';
import { optionalAuth } from './middleware/auth.js';

import authRoutes from './routes/auth.js';
import marketplaceRoutes from './routes/marketplace.js';
import documentRoutes from './routes/documents.js';
import validationRoutes from './routes/validations.js';
import userRoutes from './routes/users.js';
import activityRoutes from './routes/activity.js';
import nftRoutes from './routes/nft.js';
import kycRoutes from './routes/kyc.js';
import verifyRoutes from './routes/verify.js';

const app = express();
const PORT = Number(process.env.PORT || 4000);

// ────────────────────────────────────────────────────────────────
//  Middleware base
// ────────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : true,
  credentials: false,
}));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(optionalAuth);

// Log básico de requests en desarrollo
if (process.env.NODE_ENV !== 'production') {
  app.use((req, _res, next) => {
    const start = Date.now();
    const orig = res => res;
    next();
    process.nextTick(() => {
      const ms = Date.now() - start;
      if (req.path.startsWith('/api')) {
        console.log(`  ${req.method.padEnd(6)} ${req.path}  (${ms}ms)`);
      }
    });
  });
}

// ────────────────────────────────────────────────────────────────
//  Rutas API
// ────────────────────────────────────────────────────────────────
app.use('/api/auth',        authRoutes);
app.use('/api/marketplace', marketplaceRoutes);
app.use('/api/documents',   documentRoutes);
app.use('/api/validations', validationRoutes);
app.use('/api/users',       userRoutes);
app.use('/api/activity',    activityRoutes);
app.use('/api/nft',         nftRoutes);
app.use('/api/kyc',         kycRoutes);
app.use('/api/verify',      verifyRoutes);

/** Health check completo: API + DB + Blockchain. */
app.get('/api/health', async (_req, res) => {
  const db = await getDbStatus();
  const chain = await ettiosHealth();
  res.json({
    ok: db.ok,
    app: 'MTP Platform',
    version: '2.0.0-react',
    timestamp: new Date().toISOString(),
    db,
    blockchain: {
      name: 'ETTIOS',
      chainId: Number(process.env.ETTIOS_CHAIN_ID || 2237),
      ...chain,
    },
  });
});

/** 404 para rutas /api inexistentes. */
app.use('/api/*', (_req, res) => {
  res.status(404).json({ error: 'Endpoint no encontrado' });
});

// ────────────────────────────────────────────────────────────────
//  Handler global de errores
// ────────────────────────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  // 1) Errores de SQL → mensaje amigable
  const sql = err && err.code ? friendlySqlError(err) : null;
  if (sql) {
    console.error(`  ✗ SQL ${err.code}: ${err.message}`);
    return res.status(sql.status).json({ error: sql.message });
  }
  // 2) Errores de multer (archivo grande, tipo no permitido)
  if (err && err.message && /File too large|Tipo de archivo/.test(err.message)) {
    return res.status(400).json({ error: err.message });
  }
  // 3) Errores de JSON malformado
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'JSON inválido en el body' });
  }
  // 4) Default
  console.error('✗ Error no manejado:', err);
  res.status(500).json({ error: 'Error interno del servidor' });
});

// ────────────────────────────────────────────────────────────────
//  Arranque del servidor (con verificación de DB previa)
// ────────────────────────────────────────────────────────────────
async function start() {
  console.log('\n╔══════════════════════════════════════════════════════╗');
  console.log('║              MTP PLATFORM — Backend API              ║');
  console.log('╚══════════════════════════════════════════════════════╝\n');

  try {
    await testConnection();
  } catch {
    console.error('\n  ✗ El servidor no puede arrancar sin base de datos.');
    console.error('  ✗ Ejecutá "npm run init-db" y volvé a intentar.\n');
    process.exit(1);
  }

  app.listen(PORT, () => {
    console.log(`✓ API escuchando en http://localhost:${PORT}`);
    console.log(`  Chain: ETTIOS (id ${process.env.ETTIOS_CHAIN_ID || 2237})`);
    console.log(`  CORS:  ${process.env.CORS_ORIGIN || '* (todos)'}`);
    console.log(`\n  Endpoints principales:`);
    console.log(`    GET  /api/health`);
    console.log(`    POST /api/auth/login`);
    console.log(`    POST /api/auth/register`);
    console.log(`    GET  /api/marketplace/professionals`);
    console.log(`    GET  /api/verify/:identifier   (público)`);
    console.log(`    POST /api/nft/mint/:docId      (autenticado)\n`);
  });
}

// Manejo de señales para shutdown limpio
process.on('SIGTERM', () => { console.log('\n→ SIGTERM recibida, cerrando…'); process.exit(0); });
process.on('SIGINT',  () => { console.log('\n→ Ctrl+C recibido, cerrando…'); process.exit(0); });
process.on('unhandledRejection', (err) => {
  console.error('✗ Unhandled rejection:', err);
});

start();
